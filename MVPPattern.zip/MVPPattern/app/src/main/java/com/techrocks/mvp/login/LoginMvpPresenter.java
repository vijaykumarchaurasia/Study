package com.techrocks.mvp.login;

import com.techrocks.mvp.ui.base.MvpPresenter;

/**
 * Created by vijayk13 on 3/14/2018.
 */

public interface LoginMvpPresenter <V extends LoginMvpView> extends MvpPresenter<V> {

    void startLogin(String emailId);
}
