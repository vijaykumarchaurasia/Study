package com.techrocks.mvp;

import android.app.Application;

import com.techrocks.mvp.data.DataManager;
import com.techrocks.mvp.data.SharedPrefsHelper;

/**
 * Created by vijay Kumar on 3/14/2018.
 */

public class MVPApplication extends Application{

    DataManager dataManager;
    @Override
    public void onCreate() {
        super.onCreate();

        SharedPrefsHelper sharedPrefsHelper = new SharedPrefsHelper(getApplicationContext());
        dataManager = new DataManager(sharedPrefsHelper);

    }

    public DataManager getDataManager() {
        return dataManager;
    }

}
