package com.techrocks.mvp.login;

import com.techrocks.mvp.ui.base.MvpView;

/**
 * Created by vijayk13 on 3/14/2018.
 */

public interface LoginMvpView extends MvpView {

    void openMainActivity();

    void onLoginButtonClick();
}
