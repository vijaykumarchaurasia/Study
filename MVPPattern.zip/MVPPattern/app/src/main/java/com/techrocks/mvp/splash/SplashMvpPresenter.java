package com.techrocks.mvp.splash;

import com.techrocks.mvp.ui.base.MvpPresenter;

/**
 * Created by vijay Kumar on 3/14/2018.
 * First create interface for the Presenter which extends MvpPresenter.
 */

public interface SplashMvpPresenter <V extends SplashMvpView> extends MvpPresenter<V> {

    void decideNextActivity();
}
