package com.techrocks.mvp.splash;

import com.techrocks.mvp.data.DataManager;
import com.techrocks.mvp.ui.base.BasePresenter;

/**
 * Created by vijay Kumar on 3/14/2018
 * After creating the interface, create class for the presenter which extends BasePresenter and implements the interface we have for this presenter.
 */

public class SplashPresenter <V extends SplashMvpView> extends BasePresenter<V> implements SplashMvpPresenter<V> {

    public SplashPresenter(DataManager dataManager) {
        super(dataManager);
    }

    @Override
    public void decideNextActivity() {
        if (getDataManager().getLoggedInMode()) {
            getMvpView().openMainActivity();
        } else {
            getMvpView().openLoginActivity();
        }
    }
}
