package com.techrocks.mvp.main;

import com.techrocks.mvp.ui.base.MvpView;

/**
 * Created by vijayk13 on 3/14/2018.
 */

public interface MainMvpView extends MvpView {

    void openSplashActivity();
}
