package com.techrocks.mvp.login;

import com.techrocks.mvp.data.DataManager;
import com.techrocks.mvp.ui.base.BasePresenter;

/**
 * Created by vijayk13 on 3/14/2018.
 */

public class LoginPresenter <V extends LoginMvpView> extends BasePresenter<V> implements LoginMvpPresenter<V> {

    public LoginPresenter(DataManager dataManager) {
        super(dataManager);
    }

    @Override
    public void startLogin(String emailId) {
        getDataManager().saveEmailId(emailId);
        getDataManager().setLoggedIn();
        getMvpView().openMainActivity();
    }
}
