package com.techrocks.mvp.ui.base;

import com.techrocks.mvp.data.DataManager;

/**
 * Created by vijay Kumar on 3/14/2018.
 * It is base class for all presenter that implements MvpPresenter and it is extended by all other presenters there in application.
 */

public class BasePresenter<V extends MvpView> implements MvpPresenter<V> {

    DataManager mDataManager;
    private V mMvpView;

    public BasePresenter(DataManager dataManager) {
        mDataManager = dataManager;
    }

    @Override
    public void onAttach(V mvpView) {
        mMvpView = mvpView;
    }

    public V getMvpView() {
        return mMvpView;
    }

    public DataManager getDataManager() {
        return mDataManager;
    }
}
