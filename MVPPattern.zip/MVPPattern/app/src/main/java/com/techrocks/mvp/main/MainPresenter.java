package com.techrocks.mvp.main;

import com.techrocks.mvp.data.DataManager;
import com.techrocks.mvp.ui.base.BasePresenter;

/**
 * Created by vijayk13 on 3/14/2018.
 */

public class MainPresenter <V extends MainMvpView> extends BasePresenter<V> implements MainMvpPresenter<V> {

    public MainPresenter(DataManager dataManager) {
        super(dataManager);
    }

    @Override
    public String getEmailId() {
        return getDataManager().getEmailId();
    }

    @Override
    public void setUserLoggedOut() {
        getDataManager().clear();
        getMvpView().openSplashActivity();
    }
}
