package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

public class DataObjectWindowAction extends AbstractAction implements IWorkbenchAction{

	private static final String ID = "com.navistar.datadictionary.DataObjectWindowAction";
	public DataObjectWindowAction() {
		setId(ID);
	}
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
