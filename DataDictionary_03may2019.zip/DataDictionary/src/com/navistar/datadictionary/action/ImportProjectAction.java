package com.navistar.datadictionary.action;

import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

public class ImportProjectAction extends AbstractAction implements IWorkbenchAction{

	private static final String ID = "com.navistar.datadictionary.ImportProjectAction";
	public ImportProjectAction() {
		setId(ID);
	}
	Shell shell = new Shell();
 	
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		DirectoryDialog filedialog = new DirectoryDialog(shell);
		String result = filedialog.open();
		System.out.println("result :: "+result);
	}
 	private void onok() {
		// TODO Auto-generated method stub
 		setId("com.navistar.datadictionary.view.ProjectExplorerView");
	}
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}
	

}
