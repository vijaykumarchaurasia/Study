package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

public class TableEditorAction extends AbstractAction implements IWorkbenchAction{

	private static final String ID = "com.navistar.datadictionary.TableEditorAction";
	public TableEditorAction() {
		setId(ID);
	}
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
