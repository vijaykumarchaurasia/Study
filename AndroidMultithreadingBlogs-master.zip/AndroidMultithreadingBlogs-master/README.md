# Source Code for Android Multithreading Blogs

This is an example app for demonstrating various of multi-threading techniques. The detailed discussions of these techniques are available on my [technical blog](https://medium.com/@frank.tan).

The blogs in this series are still expanding. Available blogs are:

* [HandlerThread](https://medium.com/@frank.tan/using-handlerthread-in-android-46c285936fdd#.cbg6w03kc)

* [Thread Pool](https://medium.com/@frank.tan/using-a-thread-pool-in-android-e3c88f59d07f#.wz5n8aao6)
