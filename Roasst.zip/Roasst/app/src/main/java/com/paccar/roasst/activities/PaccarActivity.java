package com.paccar.roasst.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;

import com.paccar.roasst.device.Screen;
import com.paccar.roasst.ui.ActivityTransition;

/**
 * Created by vijayk13 on 1/17/2018.
 */
public abstract class PaccarActivity extends Activity {

    private Context context;
    private Activity activity;

    public Context getContext() {
        return context;
    }
    public Activity getActivity() {
        return activity;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        new ActivityTransition().unloadActivity(this);
    }


    public void setContext(Object self) {
        getSoftButtonsBarHeight();
        this.context = (Context) self;
        this.activity = (Activity) self;
    }

    @SuppressLint("NewApi")
    private int getSoftButtonsBarHeight() {
        // getRealMetrics is only available with API 17 and +
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            DisplayMetrics metrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(metrics);
            int usableHeight = metrics.heightPixels;
            getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
            int realHeight = metrics.heightPixels;
            if (realHeight > usableHeight) return realHeight - usableHeight;
            else return 0;
        }
        return 0;
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                new ActivityTransition().unloadActivity(this);
        }
        return super.onOptionsItemSelected(item);
    }


    @NonNull
    public Screen getScreenSize() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        Screen s = new Screen();
        s.setHeight(displayMetrics.heightPixels);
        s.setWidth(displayMetrics.widthPixels);
        return s;
    }

    @NonNull
    protected <T extends View> T $(@IdRes int id) {
        return (T) super.findViewById(id);
    }


}
