package com.paccar.roasst.root;

import android.app.Application;
import android.support.annotation.Nullable;

import com.delphi.dea600.sdk.spp.BluetoothManager;

/**
 * Created by vijayk13 on 1/17/2018.
 */

public class PaccarApplication extends Application {

    @Nullable
    private static PaccarApplication application = null;
    public BluetoothManager btManager;

    public PaccarApplication() {
        application = this;
    }

    @Nullable
    public static PaccarApplication getApplication() {
        if (application == null) application = new PaccarApplication();
        return application;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        setupBluetoothManager();

    }

    private void setupBluetoothManager()
    {
        btManager = new BluetoothManager(this);
    }

    public BluetoothManager getBluetoothManager()
    {
        return btManager;
    }
}
