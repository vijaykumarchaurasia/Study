package com.paccar.roasst.ui;

import android.app.Activity;
import android.content.Intent;

/**
 * Created by vijayk13 on 1/17/2018.
 */
public class ActivityTransition {

    public static final int RESULT_OK = 1;
    public static final int RESULT_ERROR = 0;

    public void unloadActivity(Activity activity) {
        activity.finish();
        activity.overridePendingTransition(0, 0);
    }

    public void loadActivity(final Activity activity, final Intent intent) {
        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        activity.startActivity(intent);
                        activity.overridePendingTransition(0, 0);

                    }
                }, 0);
    }

    public void loadActivityAfterUnloading(Activity activity, final Intent intent) {
        loadActivity(activity, intent);
        unloadActivity(activity);
    }


    public void loadActivityForResult(Activity activity, Intent i, int resultCode) {
        activity.startActivityForResult(i, resultCode);
        //activity.overridePendingTransition(R.animator.fade_in, R.animator.fade_out);
        activity.overridePendingTransition(0, 0);
    }
}
