package com.paccar.roasst.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresPermission;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.delphi.dea600.sdk.spp.BluetoothManager;
import com.paccar.roasst.R;
import com.paccar.roasst.root.PaccarApplication;
import com.paccar.roasst.ui.ActivityTransition;
import com.paccar.roasst.ui.StringConstant;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by vijay on 1/18/2018.
 * This class is used to establish the connection between head unit and a hand free cell phone.
 * Once the connection is established it triggers the calling application of the device and send the contact details.
 */
public class RoasstCallingActivity extends PaccarActivity {

    private static final String TAG = "RoasstCallingActivity";
    private ImageView peterbiltDialButton = null;
    private ImageView pacCentralDialButton = null;
    public String contact;


    @NonNull
    private BluetoothManager bluetoothManager;
    private BluetoothManager.StartListener mAdapterStartedListener = new BluetoothManager.StartListener() {
        @Override
        public void onStartCompleted() {
            onAdapterStarted();
        }
    };

    private BluetoothManager.BluetoothStateChangeListener mStateListener = new StateListener();
    private ArrayList<BluetoothManager.BluetoothDevice> mDevices = new ArrayList<>();
    @RequiresPermission(Manifest.permission.CALL_PHONE)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContext(this);
        setContentView(R.layout.dialog_calling_screen);

        bluetoothManager = PaccarApplication.getApplication().getBluetoothManager();
        getUIComponents();
        startBluetoothManager();

        peterbiltDialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contact = StringConstant.PETERBILT;
                requestPermissionToCall(StringConstant.PETERBILT);
            }
        });

        pacCentralDialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contact = StringConstant.PAC_CENTRAL;
                requestPermissionToCall(StringConstant.PAC_CENTRAL);
            }
        });
    }

    public void getUIComponents()
    {
        peterbiltDialButton = $(R.id.peterbiltDialButton);
        pacCentralDialButton = $(R.id.pacCentralDialButton);
    }

    private void callCustomerCenter(String contact)
    {

        Uri number = Uri.parse("tel:"+contact);
        Intent callIntent = new Intent(Intent.ACTION_CALL, number);

        // Verify it resolves
        PackageManager packageManager = getPackageManager();
        List<ResolveInfo> activities = packageManager.queryIntentActivities(callIntent, 0);


        // Start an activity if intent is safe( i.e. If calling application is present in the device)
        if (activities.size() > 0) {
            new ActivityTransition().loadActivity(getActivity(),callIntent);
            getActivity().finish();

        }
        // Calling application of the device is not available
        else
        {
            Toast.makeText(getActivity(), StringConstant.APP_NOT_AVAILABLE,Toast.LENGTH_LONG).show();
            getActivity().finish();

        }
    }

/**
 * @param permission - Permission to ask user to allow
 * @param requestCode - requestCode to use in onRequestPermissionsResult method.
 *
 */
    private void askForPermission(String permission, Integer requestCode) {
        if (ContextCompat.checkSelfPermission(getActivity(), permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), permission)) {

                //This is called if user has denied the permission before
                //In this case just asking the permission again
                ActivityCompat.requestPermissions(getActivity(), new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(getActivity(), new String[]{permission}, requestCode);
            }
        }
    }

    private void requestPermissionToCall(String contact)
    {
        askForPermission(Manifest.permission.CALL_PHONE, StringConstant.CALL);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
           return;
        }
        callCustomerCenter(contact);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if(ActivityCompat.checkSelfPermission(this, permissions[0]) == PackageManager.PERMISSION_GRANTED){

            if(requestCode == StringConstant.CALL)
            {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    if(contact!=null)
                    callCustomerCenter(contact);
                }

            }
        }
    }

    private void onAdapterStarted() {
        invalidateOptionsMenu();
        try {
            updateUIOnBluetoothState(bluetoothManager.isBluetoothOn());
        } catch (RemoteException e) {
            Log.e(TAG, "Remote exception when trying to get BT state", e);
        }
    }

    private void enableButtonView()
    {
        peterbiltDialButton.setBackgroundResource(R.drawable.button_view);
        pacCentralDialButton.setBackgroundResource(R.drawable.button_view);
    }

    private void disableButtonView(){
        peterbiltDialButton.setBackgroundResource(R.drawable.disable_button);
        pacCentralDialButton.setBackgroundResource(R.drawable.disable_button);
    }

    private void startBluetoothManager()
    {
        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        if(bluetoothManager!=null)
                        {
                            bluetoothManager.addStartListener(mAdapterStartedListener);
                            bluetoothManager.addStateListener(mStateListener);

                            // Make sure we're running on KITKAT or lower to use BluetoothManager APIs
                            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
                                bluetoothManager.start();
                            }

                        }

                    }
                }, 0);
    }

    private final class StateListener implements BluetoothManager.BluetoothStateChangeListener {
        @Override
        public void onStateChanged(final boolean state) {
            updateUIOnBluetoothState(state);
        }

        @Override
        public void onProfilesAvailable(@NonNull final BluetoothManager.BluetoothDevice bluetoothDevice,
                                        @NonNull final List<BluetoothManager.BluetoothProfiles> list) {
            final String profiles = TextUtils.join(", ", list);
            Log.d(TAG, "profiles: " + profiles);

            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    /*Toast.makeText(getActivity(),
                            "Device: " + bluetoothDevice.getDeviceName() + " Profiles: " + profiles,
                            Toast.LENGTH_SHORT).show();*/
                }
            };
            runOnUiThread(runnable);
        }
    }

    private void updateUIOnBluetoothState(final boolean state) {
        Log.d(TAG, "updateUIOnBluetoothState state: " + state);
        new android.os.Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        if(peterbiltDialButton!=null && pacCentralDialButton!=null)
                        {
                            if(state){
                                enableButtonView();
                            }
                            else{
                                disableButtonView();
                                Toast.makeText(getActivity(),StringConstant.BT_ENABLE_MESSAGE,Toast.LENGTH_SHORT).show();

                            }
                            peterbiltDialButton.setEnabled(state);
                            pacCentralDialButton.setEnabled(state);

                        }

                    }
                }, 0);

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (bluetoothManager != null) {
            bluetoothManager.removeStateListener(mStateListener);
            // Make sure we're running on KITKAT or lower to use BluetoothManager APIs
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {
                bluetoothManager.stop();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        getActivity().finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        new ActivityTransition().unloadActivity(this);
    }


}
