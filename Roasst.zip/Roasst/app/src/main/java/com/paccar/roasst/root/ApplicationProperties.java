package com.paccar.roasst.root;

/**
 * Created by vijayk13 on 1/17/2018.
 */

public class ApplicationProperties {

    public static final int WAIT_TIME = 45;
    public static final int RELEASE = 1;
    public static final int DEBUG = 0;

    // HTTP Client Configuration.
    public static final int CONNECTION_TIMEOUT = 30;
    public static final int READ_WRITE_TIMEOUT = 120;
}
