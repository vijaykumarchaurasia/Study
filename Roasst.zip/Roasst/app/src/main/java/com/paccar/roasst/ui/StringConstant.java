package com.paccar.roasst.ui;

/**
 * Created by vijay  on 1/18/2018.
 */
public interface StringConstant {
    public static final String APP_NOT_AVAILABLE = "Supporting calling application is not available.";
    public static final String BT_ENABLE_MESSAGE = "Please enable the Bluetooth to place a call.";
    public static final String BT_STATE = " Bluetooth state changed to";
    public static final String APK_VERSION = "27 Feb 2018_V1.0.";
    public static final Integer CALL = 2;
    public static final String PETERBILT = "18004738372";
    public static final String PAC_CENTRAL = "918928485985";
    public static final String KENWORTH = "18005927747";


}
