package com.techrocks.mvp.ui.base;

/**
 * Created by vijay Kumar on 3/14/2018.
 * It is an interface that is implemented by BasePresenter, it acts as base presenter interface that is extended by all other presenter interfaces.
 */

public interface MvpPresenter<V extends MvpView> {
    void onAttach(V mvpView);
}
