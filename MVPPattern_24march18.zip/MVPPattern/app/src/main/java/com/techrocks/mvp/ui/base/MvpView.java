package com.techrocks.mvp.ui.base;

/**
 * Created by vijay Kumar on 3/14/2018.
 * It is an interface that is implemented by BaseActivity, it acts as a base view that is extended by all other view interfaces.
 */

public interface MvpView {
}
