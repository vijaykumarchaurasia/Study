package com.techrocks.mvp.splash;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.techrocks.mvp.MVPApplication;
import com.techrocks.mvp.R;
import com.techrocks.mvp.data.DataManager;
import com.techrocks.mvp.login.LoginActivity;
import com.techrocks.mvp.main.MainActivity;
import com.techrocks.mvp.ui.base.BaseActivity;

/**
 * Created by vijay Kumar on 3/14/2018
 * After creating the interface, create the class for the view which extends BaseActivity and implements the interface we have for this view.
 */
public class SplashActivity extends BaseActivity implements SplashMvpView{

    SplashPresenter mSplashPresenter;

    public static Intent getStartIntent(Context context) {
        Intent intent = new Intent(context, SplashActivity.class);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        DataManager dataManager = ((MVPApplication) getApplication()).getDataManager();

        mSplashPresenter = new SplashPresenter(dataManager);

        mSplashPresenter.onAttach(this);

        mSplashPresenter.decideNextActivity();
    }

    @Override
    public void openMainActivity() {
        Intent intent = MainActivity.getStartIntent(this);
        startActivity(intent);
        finish();

    }

    @Override
    public void openLoginActivity() {

        Intent intent = LoginActivity.getStartIntent(this);
        startActivity(intent);
        finish();

    }
}
