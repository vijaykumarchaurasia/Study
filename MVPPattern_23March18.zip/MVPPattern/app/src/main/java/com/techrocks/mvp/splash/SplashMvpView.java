package com.techrocks.mvp.splash;

import com.techrocks.mvp.ui.base.MvpView;

/**
 * Created by vijay Kumar on 3/14/2018.
 * First create interface for the view which extends MvpView.
 */

public interface SplashMvpView extends MvpView {

    void openMainActivity();

    void openLoginActivity();

}
