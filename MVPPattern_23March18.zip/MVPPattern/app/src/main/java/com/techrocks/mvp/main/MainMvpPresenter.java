package com.techrocks.mvp.main;

import com.techrocks.mvp.ui.base.MvpPresenter;

/**
 * Created by vijay Kumar on 3/14/2018.
 */

public interface MainMvpPresenter <V extends MainMvpView> extends MvpPresenter<V> {

    String getEmailId();

    void setUserLoggedOut();
}
