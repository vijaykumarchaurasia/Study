package com.navistar.datadictionary.view;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

public class WelcomeNoteView extends ViewPart// implements IPropertyListener 
{
	public static final String ID = "com.navistar.datadictionary.view.WelcomeNoteView";

	public WelcomeNoteView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		
		 Composite container = new Composite(parent, SWT.NONE);
		    container.setLayout(new GridLayout(2, false));

		    Label lblDeptNo = new Label(container, SWT.NONE);
		    lblDeptNo.setLayoutData(new GridData(SWT.BOTTOM, SWT.CENTER, false,
		            false, 1, 1));
		    lblDeptNo.setText("WelcomeNote View");

	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}

	

}
