package com.navistar.datadictionary;

import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

/**
 * An action bar advisor is responsible for creating, adding, and disposing of
 * the actions added to a workbench window. Each window will be populated with
 * new actions.
 */
public class ApplicationActionBarAdvisor extends ActionBarAdvisor {

	// Actions - important to allocate these only in makeActions, and then use
	// them
	// in the fill methods. This ensures that the actions aren't recreated
	// when fillActionBars is called with FILL_PROXY.

	 private IWorkbenchAction saveAction;
	  private IWorkbenchAction exitAction;
	  private IWorkbenchAction aboutAction;
	 
	  public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
	      super(configurer);
	  }
	 
	  @Override
	  protected void makeActions(IWorkbenchWindow window) {
	 
	      saveAction = ActionFactory.SAVE.create(window);
	      this.register(saveAction);
	 
	      exitAction = ActionFactory.QUIT.create(window);
	      this.register(exitAction);
	 
	      aboutAction = ActionFactory.ABOUT.create(window);
	      this.register(aboutAction);
	 
	      super.makeActions(window);
	  }
	 
	  @Override
	  protected void fillMenuBar(IMenuManager menuBar) {
	      // File
	      MenuManager fileMenu = new MenuManager("&File", "file");
	      menuBar.add(fileMenu);
	      fileMenu.add(exitAction);
	 
	      // Help
	      MenuManager helpMenu = new MenuManager("&Help", "help");
	      menuBar.add(helpMenu);
	      helpMenu.add(aboutAction);
	 
	      super.fillMenuBar(menuBar);
	  }
	 
	  @Override
	  protected void fillCoolBar(ICoolBarManager coolBar) {
	      IToolBarManager toolBar1 = new ToolBarManager(SWT.FLAT | SWT.RIGHT );
	      toolBar1.add(saveAction);
	 
	      coolBar.add(toolBar1);
	 
	      IToolBarManager toolBar2 = new ToolBarManager(SWT.FLAT | SWT.RIGHT );
	 
	      toolBar2.add(exitAction);
	      coolBar.add(toolBar2);
	  }

}
