package rcpapplication.workbench;

import org.eclipse.swt.widgets.Composite;

public class WelcomeNoteWorkbench extends AbstractWorkbenchpart{

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}

}
