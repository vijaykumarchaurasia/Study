package rcpapplication.constant;

public class MyConstants {
	public static final int EDITOR_DATA_CHANGED = 999999; 

}
