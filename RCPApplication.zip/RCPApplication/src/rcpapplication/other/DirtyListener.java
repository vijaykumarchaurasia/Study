package rcpapplication.other;

public interface DirtyListener {
	public void fireDirty();

}
