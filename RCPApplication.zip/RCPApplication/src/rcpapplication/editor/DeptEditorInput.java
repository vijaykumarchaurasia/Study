package rcpapplication.editor;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

import rcpapplication.model.Department;

public class DeptEditorInput implements IEditorInput {
	 
	  private Department dept;
	 
	  public DeptEditorInput(Department dept) {
	      this.dept = dept;
	  }
	 
	  public Department getDept() {
	      return dept;
	  }
	 
	  @SuppressWarnings("rawtypes")
	  @Override
	  public Object getAdapter(Class adapter) {
	      return null;
	  }
	 
	  @Override
	  public boolean exists() {
	      return false;
	  }
	 
	  @Override
	  public ImageDescriptor getImageDescriptor() {
	      return null;
	  }
	 
	  @Override
	  public String getName() {
	      // Required!!
	      return "Department";
	  }
	 
	  @Override
	  public IPersistableElement getPersistable() {
	      return null;
	  }
	 
	  @Override
	  public String getToolTipText() {
	      // Required!!
	      return "Department";
	  }
	 
	}