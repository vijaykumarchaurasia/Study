package com.navistar.datadictionary.categories.editor;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.DefaultNatTableStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IEditableRule;
import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.data.ListDataProvider;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultColumnHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultCornerDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultRowHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.layer.ColumnHeaderLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.CornerLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.GridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.RowHeaderLayer;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.viewport.ViewportLayer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IReusableEditor;
import org.eclipse.ui.IWorkbenchPartConstants;

import com.navistar.datadictionary.categories.editorinput.CategoryEditorInput;
import com.navistar.datadictionary.editor.AbstractBaseEditor;
import com.navistar.datadictionary.model.Category;
import com.navistar.datadictionary.model.Department;
import com.navistar.datadictionary.model.DepartmentDAO;
import com.navistar.datadictionary.provider.DepartmentColumnPropertyAccessor;

public class InputEditor extends AbstractBaseEditor implements IReusableEditor{
	public static final String ID = "com.navistar.datadictionary.categories.editor.InputEditor";
	
	private Text text_cat_id;
	private Text text_cat_Name;

	public InputEditor() {
	}

	@Override
	public void showData() {
		CategoryEditorInput inputEditor = (CategoryEditorInput) this.getEditorInput();
		Category category = inputEditor.getCategory();
		
	   //this.setInput(inputEditor);
	   this.text_cat_id.setText(category.getCategoryId() == null ? "" : category.getCategoryId());
	   this.text_cat_Name.setText(category.getCategoryName() == null ? "" : category.getCategoryName());
	   // Clear dirty.
	   this.setDirty(false);
	   this.setPartName(category.getCategoryName() == null ? "" : category.getCategoryName());
	   this.setContentDescription(category.getCategoryName() == null ? "" : category.getCategoryName());
	   this.setTitleToolTip(category.getCategoryName() == null ? "" : category.getCategoryName());
	   this.setTitle(category.getCategoryName() == null ? "" : category.getCategoryName());
	   this.setPartProperty(category.getCategoryName() == null ? "" : category.getCategoryName(),category.getCategoryName() == null ? "" : category.getCategoryName());
	   

	}
	
	public void displayEditorGUI(Composite parent)
	{	
		
		
		   Composite container = new Composite(parent, SWT.NONE);
	       container.setLayout(new GridLayout(2, false));
	 
	       Label lblDeptNo = new Label(container, SWT.NONE);
	       lblDeptNo.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
	               false, 1, 1));
	       lblDeptNo.setText("Category ID");
	 
	       text_cat_id = new Text(container, SWT.BORDER);
	       text_cat_id.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true,
	               false, 1, 1));
	 
	       Label lblDeptName = new Label(container, SWT.NONE);
	       lblDeptName.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
	               false, 1, 1));
	       lblDeptName.setText("Category Name");
	       
	       text_cat_Name = new Text(container, SWT.BORDER);
	       text_cat_Name.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true,
	               false, 1, 1));
		
	}
	

	@Override
	protected void createPartControl2(Composite parent) {
		
		
		/*CategoryEditorInput inputEditor = (CategoryEditorInput) this.getEditorInput();
		Category category = inputEditor.getCategory();
		System.out.println("category name:"+category.getCategoryName());*/
		
		//displaytable(parent);
		displayEditorGUI(parent);	   
		   
	}
	
	@Override
	public void setInput(IEditorInput input) {
       super.setInput(input);
       firePropertyChange(IWorkbenchPartConstants.PROP_INPUT);
	}
	
	public Category getCategoryDetails()
	{
		CategoryEditorInput inputEditor = (CategoryEditorInput) this.getEditorInput();
		Category category = inputEditor.getCategory();
		
		return category;
		
	}

	@Override
	protected Control[] registryDirtyControls() {
		return null;
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
	}

	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}
	
	@Override
	protected void setPartName(String partName) {
		// TODO Auto-generated method stub
		super.setPartName(partName);
	}
	
	@Override
	protected void setTitleToolTip(String toolTip) {
		// TODO Auto-generated method stub
		super.setTitleToolTip(toolTip);
	}
	
	@Override
	protected void setContentDescription(String description) {
		// TODO Auto-generated method stub
		super.setContentDescription(description);
	}
	
	@Override
	protected void setTitle(String title) {
		// TODO Auto-generated method stub
		super.setTitle("title");
	}
	
	/*@Override
	public void setInput(IEditorInput input) {
		// TODO Auto-generated method stub
		super.setInput(input);
	}*/
	
	
	
	
	
   private void displaytable(Composite parent)
   {	   

		
		parent.setLayout(new GridLayout(2,false));
		Button btnAddDataObj = new Button(parent, SWT.PUSH);
		btnAddDataObj.setBounds(10, 20, 75, 25);
		btnAddDataObj.setText("Add data object");
		
		Button btnNewButton = new Button(parent, SWT.PUSH);
		btnNewButton.setBounds(10, 20, 75, 25);
		btnNewButton.setText("Find in model");
		
		// property names of the Department class
		String[] propertyNames = { "deptId", "deptNo", "deptName", "location" };
		   
		// mapping from property to label, needed for column header labels
		Map<String, String> propertyToLabelMap = new HashMap<String, String>();
		propertyToLabelMap.put("deptId", "Department_ID");
		propertyToLabelMap.put("deptNo", "Department_No");
		propertyToLabelMap.put("deptName", "Department_Name");
		propertyToLabelMap.put("location", "Department_Location");
		
		// create the data provider
		//IColumnPropertyAccessor<Department> columnPropertyAccessor = new ReflectiveColumnPropertyAccessor<Department>(propertyNames);
		IColumnPropertyAccessor<Department> columnPropertyAccessor = new DepartmentColumnPropertyAccessor();

		IDataProvider bodyDataProvider =
		           new ListDataProvider<Department>(
		           		DepartmentDAO.listDepartment(), columnPropertyAccessor);
		   
		   final DataLayer bodyDataLayer = new DataLayer(bodyDataProvider);
		   //DepartmentHeaderDataProvider headerDataProvider = new DepartmentHeaderDataProvider();
		   
		   SelectionLayer selectionLayer = new SelectionLayer(bodyDataLayer);
		   ViewportLayer viewportLayer = new ViewportLayer(selectionLayer);
		   
		   // build the column header layer stack
		   IDataProvider columnHeaderDataProvider = new DefaultColumnHeaderDataProvider(propertyNames, propertyToLabelMap);
		   DataLayer columnHeaderDataLayer = new DataLayer(columnHeaderDataProvider);
		   ILayer columnHeaderLayer = new ColumnHeaderLayer(columnHeaderDataLayer,
				    										viewportLayer,
				    										selectionLayer);
				
		   // build the row header layer stack
		   IDataProvider rowHeaderDataProvider = new DefaultRowHeaderDataProvider(bodyDataProvider);
		   DataLayer rowHeaderDataLayer = new DataLayer(rowHeaderDataProvider, 40, 20);
		   ILayer rowHeaderLayer = new RowHeaderLayer(rowHeaderDataLayer,viewportLayer,selectionLayer);
		   
		   // build the corner layer stack
		   IDataProvider cornerDataProvider = new DefaultCornerDataProvider(columnHeaderDataProvider,rowHeaderDataProvider);
		   DataLayer cornerDataLayer = new DataLayer(cornerDataProvider);
		   ILayer cornerLayer = new CornerLayer(cornerDataLayer,rowHeaderLayer,columnHeaderLayer);

		   // create the grid layer composed with
		   // the prior created layer stacks
		   GridLayer gridLayer = new GridLayer(viewportLayer,columnHeaderLayer,rowHeaderLayer,cornerLayer);
		   //DefaultGridLayer gridLayer = new DefaultGridLayer(bodyDataProvider, headerDataProvider);
		   NatTable natTable = new NatTable(parent, gridLayer, false);
		  
		   natTable.addConfiguration(new DefaultNatTableStyleConfiguration());
		   natTable.addConfiguration(new AbstractRegistryConfiguration() {

		       @Override
		       public void configureRegistry(IConfigRegistry configRegistry) {
		           configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,
		                   IEditableRule.ALWAYS_EDITABLE);		         
		       }
		   });

		   natTable.configure();
		   GridDataFactory.fillDefaults().grab(true, true).applyTo(natTable);
		   
		   
	
	   
   }

@Override
public void setPartProperty(String key, String value) {
	// TODO Auto-generated method stub
	super.setPartProperty(key, value);
}
	
}
