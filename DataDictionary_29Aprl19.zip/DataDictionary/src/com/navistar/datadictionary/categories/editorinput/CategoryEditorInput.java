package com.navistar.datadictionary.categories.editorinput;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

import com.navistar.datadictionary.constant.MyConstants;
import com.navistar.datadictionary.model.Category;

public class CategoryEditorInput implements IEditorInput{
	
	private Category category;

	public CategoryEditorInput(Category category) {
		// TODO Auto-generated constructor stub
		this.category = category;
	}
	
	public Category getCategory()
	{
		return category;
	}

	/*@Override
	public <T> T getAdapter(Class<T> adapter) {
		// TODO Auto-generated method stub
		return null;
	}*/

	@Override
	public boolean exists() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ImageDescriptor getImageDescriptor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		//return MyConstants.CATEGORY_INPUT;
		return category.getCategoryName();
	}
	
	
	

	@Override
	public IPersistableElement getPersistable() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getToolTipText() {
		// TODO Auto-generated method stub
		return MyConstants.CATEGORY_INPUT;
	}

	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
