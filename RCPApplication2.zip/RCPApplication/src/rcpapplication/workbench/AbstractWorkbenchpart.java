package rcpapplication.workbench;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IPropertyListener;
import org.eclipse.ui.part.WorkbenchPart;

public abstract class AbstractWorkbenchpart extends WorkbenchPart{

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#addPropertyListener(org.eclipse.ui.IPropertyListener)
	 */
	@Override
	public void addPropertyListener(IPropertyListener l) {
		// TODO Auto-generated method stub
		super.addPropertyListener(l);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#dispose()
	 */
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		super.dispose();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#firePropertyChange(int)
	 */
	@Override
	protected void firePropertyChange(int propertyId) {
		// TODO Auto-generated method stub
		super.firePropertyChange(propertyId);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getConfigurationElement()
	 */
	@Override
	protected IConfigurationElement getConfigurationElement() {
		// TODO Auto-generated method stub
		return super.getConfigurationElement();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
	 */
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#showBusy(boolean)
	 */
	@Override
	public void showBusy(boolean busy) {
		// TODO Auto-generated method stub
		super.showBusy(busy);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#addPartPropertyListener(org.eclipse.jface.util.IPropertyChangeListener)
	 */
	@Override
	public void addPartPropertyListener(IPropertyChangeListener listener) {
		// TODO Auto-generated method stub
		super.addPartPropertyListener(listener);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#firePartPropertyChanged(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	protected void firePartPropertyChanged(String key, String oldValue, String newValue) {
		// TODO Auto-generated method stub
		super.firePartPropertyChanged(key, oldValue, newValue);
	}

	
	
	

}
