package rcpapplication.view;

import java.util.Map;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.IPropertyListener;
import org.eclipse.ui.IViewSite;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.ViewPart;

public class DeptView extends ViewPart implements IPropertyListener
{
	
	public static final String ID = "view.dept";

	public DeptView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		
		
		 Composite container = new Composite(parent, SWT.NONE);
		    container.setLayout(new GridLayout(2, false));

		    Label lblDeptNo = new Label(container, SWT.NONE);
		    lblDeptNo.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
		            false, 1, 1));
		    lblDeptNo.setText("Dept No");
		

	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}
	
	

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#addPropertyListener(org.eclipse.ui.IPropertyListener)
	 */
	@Override
	public void addPropertyListener(IPropertyListener l) {
		// TODO Auto-generated method stub
		super.addPropertyListener(l);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#dispose()
	 */
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		super.dispose();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#firePropertyChange(int)
	 */
	@Override
	protected void firePropertyChange(int propertyId) {
		// TODO Auto-generated method stub
		super.firePropertyChange(propertyId);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getAdapter(java.lang.Class)
	 */
	@Override
	public Object getAdapter(Class adapter) {
		// TODO Auto-generated method stub
		return super.getAdapter(adapter);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getConfigurationElement()
	 */
	@Override
	protected IConfigurationElement getConfigurationElement() {
		// TODO Auto-generated method stub
		return super.getConfigurationElement();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getDefaultImage()
	 */
	@Override
	protected Image getDefaultImage() {
		// TODO Auto-generated method stub
		return super.getDefaultImage();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getSite()
	 */
	@Override
	public IWorkbenchPartSite getSite() {
		// TODO Auto-generated method stub
		return super.getSite();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getTitle()
	 */
	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return super.getTitle();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getTitleImage()
	 */
	@Override
	public Image getTitleImage() {
		// TODO Auto-generated method stub
		return super.getTitleImage();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getTitleToolTip()
	 */
	@Override
	public String getTitleToolTip() {
		// TODO Auto-generated method stub
		return super.getTitleToolTip();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#removePropertyListener(org.eclipse.ui.IPropertyListener)
	 */
	@Override
	public void removePropertyListener(IPropertyListener l) {
		// TODO Auto-generated method stub
		super.removePropertyListener(l);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setSite(org.eclipse.ui.IWorkbenchPartSite)
	 */
	@Override
	protected void setSite(IWorkbenchPartSite site) {
		// TODO Auto-generated method stub
		super.setSite(site);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setTitle(java.lang.String)
	 */
	@Override
	protected void setTitle(String title) {
		// TODO Auto-generated method stub
		super.setTitle(title);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setTitleImage(org.eclipse.swt.graphics.Image)
	 */
	@Override
	protected void setTitleImage(Image titleImage) {
		// TODO Auto-generated method stub
		super.setTitleImage(titleImage);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setTitleToolTip(java.lang.String)
	 */
	@Override
	protected void setTitleToolTip(String toolTip) {
		// TODO Auto-generated method stub
		super.setTitleToolTip(toolTip);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#showBusy(boolean)
	 */
	@Override
	public void showBusy(boolean busy) {
		// TODO Auto-generated method stub
		super.showBusy(busy);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getPartName()
	 */
	@Override
	public String getPartName() {
		// TODO Auto-generated method stub
		return super.getPartName();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getContentDescription()
	 */
	@Override
	public String getContentDescription() {
		// TODO Auto-generated method stub
		return super.getContentDescription();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getOrientation()
	 */
	@Override
	public int getOrientation() {
		// TODO Auto-generated method stub
		return super.getOrientation();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#addPartPropertyListener(org.eclipse.jface.util.IPropertyChangeListener)
	 */
	@Override
	public void addPartPropertyListener(IPropertyChangeListener listener) {
		// TODO Auto-generated method stub
		super.addPartPropertyListener(listener);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#removePartPropertyListener(org.eclipse.jface.util.IPropertyChangeListener)
	 */
	@Override
	public void removePartPropertyListener(IPropertyChangeListener listener) {
		// TODO Auto-generated method stub
		super.removePartPropertyListener(listener);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#firePartPropertyChanged(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	protected void firePartPropertyChanged(String key, String oldValue, String newValue) {
		// TODO Auto-generated method stub
		super.firePartPropertyChanged(key, oldValue, newValue);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#setPartProperty(java.lang.String, java.lang.String)
	 */
	@Override
	public void setPartProperty(String key, String value) {
		// TODO Auto-generated method stub
		super.setPartProperty(key, value);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getPartProperty(java.lang.String)
	 */
	@Override
	public String getPartProperty(String key) {
		// TODO Auto-generated method stub
		return super.getPartProperty(key);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.WorkbenchPart#getPartProperties()
	 */
	@Override
	public Map getPartProperties() {
		// TODO Auto-generated method stub
		return super.getPartProperties();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.ViewPart#getViewSite()
	 */
	@Override
	public IViewSite getViewSite() {
		// TODO Auto-generated method stub
		return super.getViewSite();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.ViewPart#init(org.eclipse.ui.IViewSite)
	 */
	@Override
	public void init(IViewSite site) throws PartInitException {
		// TODO Auto-generated method stub
		super.init(site);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.ViewPart#init(org.eclipse.ui.IViewSite, org.eclipse.ui.IMemento)
	 */
	@Override
	public void init(IViewSite site, IMemento memento) throws PartInitException {
		// TODO Auto-generated method stub
		super.init(site, memento);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.ViewPart#saveState(org.eclipse.ui.IMemento)
	 */
	@Override
	public void saveState(IMemento memento) {
		// TODO Auto-generated method stub
		super.saveState(memento);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.ViewPart#setPartName(java.lang.String)
	 */
	@Override
	protected void setPartName(String partName) {
		// TODO Auto-generated method stub
		super.setPartName(partName);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.ViewPart#setContentDescription(java.lang.String)
	 */
	@Override
	protected void setContentDescription(String description) {
		// TODO Auto-generated method stub
		super.setContentDescription(description);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.part.ViewPart#setInitializationData(org.eclipse.core.runtime.IConfigurationElement, java.lang.String, java.lang.Object)
	 */
	@Override
	public void setInitializationData(IConfigurationElement cfig, String propertyName, Object data) {
		// TODO Auto-generated method stub
		super.setInitializationData(cfig, propertyName, data);
	}

	@Override
	public void propertyChanged(Object source, int propId) {
		// TODO Auto-generated method stub
		
	}

	/*@Override
	public void propertyChanged(Object source, int propId) {
		// TODO Auto-generated method stub
		
	}*/
	
	
	

}
