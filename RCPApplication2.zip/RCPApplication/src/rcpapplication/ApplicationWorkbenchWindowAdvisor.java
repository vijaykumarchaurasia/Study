package rcpapplication;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IPartListener2;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchPartReference;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

import rcpapplication.editor.DeptEditor;
import rcpapplication.view.DeptListView;
import rcpapplication.view.DeptView;

public class ApplicationWorkbenchWindowAdvisor extends WorkbenchWindowAdvisor {
	 
	   public ApplicationWorkbenchWindowAdvisor(
	           IWorkbenchWindowConfigurer configurer) {
	       super(configurer);
	   }
	 
	   public ActionBarAdvisor createActionBarAdvisor(
	           IActionBarConfigurer configurer) {
	       return new ApplicationActionBarAdvisor(configurer);
	   }
	 
	   public void preWindowOpen() {
	       IWorkbenchWindowConfigurer configurer = getWindowConfigurer();
	       configurer.setInitialSize(new Point(400, 300));
	       configurer.setShowCoolBar(true);
	       configurer.setShowStatusLine(true);
	       configurer.setShowPerspectiveBar(true);
	       configurer.setTitle("RCP Application");
	   }
	 
	   @Override
	   public void postWindowOpen() {
//	       Shell shell = getWindowConfigurer().getWindow().getShell();
//	       shell.setMaximized(true);
	       
	    // Register at events related to the components of the page (View, Editor,..)
	       PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
	               .addPartListener(new IPartListener2() {          
	          
	                   // When a View or Editor opened.
	                   @Override
	                   public void partOpened(IWorkbenchPartReference partRef) {
	                       System.out.println("Part OPENED: "
	                               + partRef.getPartName());
	                       IWorkbenchPart part = partRef.getPart(false);
	                       if (part instanceof DeptListView) {
	                           DeptListView deptListView = (DeptListView) part;
	        
	                           DeptEditor deptEditor = (DeptEditor) partRef
	                                   .getPage().findView(DeptEditor.ID);
	                            
	              
	                           // DeptListView listen to Property Change of DeptEditor.
	                           if (deptEditor != null) {
	                               deptEditor.addPropertyListener(deptListView);
	                           }
	                       } else if (part instanceof DeptView) {
	                           DeptView deptView = (DeptView) part;
	        
	                           DeptEditor deptEditor = (DeptEditor) partRef
	                                   .getPage().findView(DeptEditor.ID);
	                 
	                           // DeptView listen to Property Change of DeptEditor.
	                           if (deptEditor != null) {
	                               deptEditor.addPropertyListener(deptView);
	                           }
	                       } else if (part instanceof DeptEditor) {
	                           DeptEditor deptEditor = (DeptEditor) part;
	                           DeptView deptView = (DeptView) partRef.getPage()
	                                   .findView(DeptView.ID);
	        
	                  
	                           // DeptView listen to Property Change of DeptEditor.
	                           if (deptView != null) {
	                               deptEditor.addPropertyListener(deptView);
	                           }
	        
	                           DeptListView deptListView = (DeptListView) partRef
	                                   .getPage().findView(DeptListView.ID);
	        
	                 
	                           // DeptListView listen to Property Change of DeptEditor.
	                           if (deptListView != null) {
	                               deptEditor.addPropertyListener(deptListView);
	                           }
	                       }
	                   }

					@Override
					public void partActivated(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partBroughtToTop(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partClosed(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partDeactivated(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partHidden(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partVisible(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partInputChanged(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}
	               });
	   }
	}