package rcpapplication.model;

public class DataException extends Exception {
	 
	  private static final long serialVersionUID = 7155764478659670087L;
	 
	  public DataException(String message) {
	      super(message);
	  }
	}