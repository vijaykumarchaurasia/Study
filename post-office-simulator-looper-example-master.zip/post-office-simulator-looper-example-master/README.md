###This Android project uses Looper, Handler, and HandlerThread to simulate a Post Office. The Simulation creates few BOTs who communicates among themselves using PostOffice. The communication feed is displayed live using RecyclerView.

- Clone, build and run to get most out of it.

<hr />
<p align="center">
  <img src="https://janishar.github.io/images/postoffice-simulation.png" width="300">
</p>

###[Check out Mindorks awesome open source projects here](https://mindorks.com/open-source-projects)
