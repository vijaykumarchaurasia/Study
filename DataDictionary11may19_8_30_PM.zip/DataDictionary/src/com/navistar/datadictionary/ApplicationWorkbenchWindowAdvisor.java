package com.navistar.datadictionary;

import java.util.LinkedList;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.graphics.Point;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

import com.navistar.datadictionary.categories.editor.WelcomeNoteEditor;
import com.navistar.datadictionary.categories.editorinput.WelcomeNoteEditorInput;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.service.ContextMenuService;
import com.navistar.datadictionary.service.WorkspaceService;
import com.navistar.datadictionary.view.ProjectExplorerView;

public class ApplicationWorkbenchWindowAdvisor extends WorkbenchWindowAdvisor {
	 
	   public ApplicationWorkbenchWindowAdvisor(
	           IWorkbenchWindowConfigurer configurer) {
	       super(configurer);
	   }
	 
	   public ActionBarAdvisor createActionBarAdvisor(
	           IActionBarConfigurer configurer) {
	       return new ApplicationActionBarAdvisor(configurer);
	   }
	 
	   public void preWindowOpen() {
	       IWorkbenchWindowConfigurer configurer = getWindowConfigurer();
	       configurer.setInitialSize(new Point(400, 300));
	       configurer.setShowCoolBar(true);
	       configurer.setShowStatusLine(true);
	       configurer.setShowPerspectiveBar(true);
	       configurer.setTitle("Data Dictionary");
	   }
	   
	   @Override
		public void postWindowOpen() {
			getWindowConfigurer().getWindow().getShell().setMaximized( true );
			IWorkbenchPage page =  PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
			LinkedList<Project> projectList = new LinkedList<>();
			try {
				IViewPart projectView = page.showView("com.navistar.datadictionary.view.ProjectExplorerView");
				//Load workspace history
				String resourcePath = ResourcesPlugin.getWorkspace().getRoot().getLocation().toString();
				WorkspaceService workspaceObject = new WorkspaceService();
				projectList = workspaceObject.getWorkspaceHistory(resourcePath+"/workspace.json");
				TreeViewer viewer = null;
				ProjectExplorerView projectExplorerView = (ProjectExplorerView)projectView;
				if(projectList.size()>0)
				{
					for(Project project : projectList)
					{
						viewer = projectExplorerView.importProject(project.getPath(), project.getStatus());
					}
					ContextMenuService contextMenuService = new ContextMenuService();
					contextMenuService.loadProjectStatusFromWorkspace(viewer, ProjectExplorerView.nodes);
				}
				else
				{
					//do nothing
				}
			
				//final IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();						
				WelcomeNoteEditorInput welcomeNoteEditorObject = new WelcomeNoteEditorInput();
			    page.openEditor(welcomeNoteEditorObject, WelcomeNoteEditor.ID); // the id in your plugin.xml of your editor

				} catch (PartInitException pie) {
					pie.printStackTrace();
				}
	   }
	 
	/*   
	   @Override
	   public void postWindowOpen() {
//	       Shell shell = getWindowConfigurer().getWindow().getShell();
//	       shell.setMaximized(true);
	       
	    // Register at events related to the components of the page (View, Editor,..)
	       PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
	               .addPartListener(new IPartListener2() {          
	          
	                   // When a View or Editor opened.
	                   @Override
	                   public void partOpened(IWorkbenchPartReference partRef) {
	                       System.out.println("Part OPENED: "
	                               + partRef.getPartName());
	                       IWorkbenchPart part = partRef.getPart(false);
	                       
	                       if (part instanceof WelcomeNoteView) {
	                           WelcomeNoteView deptListView = (WelcomeNoteView) part;
	        
	                           DeptEditor deptEditor = (DeptEditor) partRef
	                                   .getPage().findView(DeptEditor.ID);
	                            
	              
	                           // WelcomeNoteView listen to Property Change of DeptEditor.
	                           if (deptEditor != null) {
	                               deptEditor.addPropertyListener(deptListView);
	                           }
	                       } else if (part instanceof ActivityLogView) {
	                           ActivityLogView deptView = (ActivityLogView) part;
	        
	                           DeptEditor deptEditor = (DeptEditor) partRef
	                                   .getPage().findView(DeptEditor.ID);
	                 
	                           // ActivityLogView listen to Property Change of DeptEditor.
	                           if (deptEditor != null) {
	                               deptEditor.addPropertyListener(deptView);
	                           }
	                       } else if (part instanceof DeptEditor) {
	                           DeptEditor deptEditor = (DeptEditor) part;
	                           ActivityLogView deptView = (ActivityLogView) partRef.getPage()
	                                   .findView(ActivityLogView.ID);
	        
	                  
	                           // ActivityLogView listen to Property Change of DeptEditor.
	                           if (deptView != null) {
	                               deptEditor.addPropertyListener(deptView);
	                           }
	        
	                           WelcomeNoteView deptListView = (WelcomeNoteView) partRef
	                                   .getPage().findView(WelcomeNoteView.ID);
	        
	                 
	                           // WelcomeNoteView listen to Property Change of DeptEditor.
	                           if (deptListView != null) {
	                               deptEditor.addPropertyListener(deptListView);
	                           }
	                       }
	                   }

					@Override
					public void partActivated(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partBroughtToTop(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partClosed(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partDeactivated(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partHidden(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partVisible(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partInputChanged(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}
	               });
	   }
	   */
	}