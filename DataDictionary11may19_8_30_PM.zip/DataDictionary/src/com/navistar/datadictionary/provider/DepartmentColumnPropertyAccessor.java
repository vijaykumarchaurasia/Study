package com.navistar.datadictionary.provider;

import java.util.Arrays;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;

import com.navistar.datadictionary.model.Department;

public class DepartmentColumnPropertyAccessor implements IColumnPropertyAccessor<Department> {

	 private static final List<String> propertyNames =
		        Arrays.asList("deptId", "deptNo", "deptName", "location");
	 
	 @Override
	    public Object getDataValue(Department dept, int columnIndex) {
	        switch (columnIndex) {
	            case 0:
	                return dept.getDeptId();
	            case 1:
	                return dept.getDeptNo();
	            case 2:
	                return dept.getDeptName();
	            case 3:
	                return dept.getLocation();
	            }
	        return dept;
	    }

	    @Override
	    public void setDataValue(Department dept, int columnIndex, Object newValue) {
	        switch (columnIndex) {
	            case 0:
	                //String firstName = String.valueOf(newValue);
	                dept.setDeptId(1);
	                break;
	            case 1:
	                //String lastName = String.valueOf(newValue);
	                dept.setDeptNo("1");
	                break;
	            case 2:
	                dept.setDeptName("department name 1");
	                break;
	            case 3:
	                dept.setLocation("department 1 location");
	                break;
	        }
	    }

	    @Override
	    public int getColumnCount() {
	        return 4;
	    }

	    @Override
	    public String getColumnProperty(int columnIndex) {
	        return propertyNames.get(columnIndex);
	    }

	    @Override
	    public int getColumnIndex(String propertyName) {
	        return propertyNames.indexOf(propertyName);
	    }
}
