package com.navistar.datadictionary.provider;

import java.util.Vector;

import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

import com.navistar.datadictionary.other.Node;

public class TreeContentProvider implements ITreeContentProvider{
	
	  public Object[] getChildren(Object parentElement) {
	    Vector subcats = ((Node) parentElement).getSubCategories();
	    return subcats == null ? new Object[0] : subcats.toArray();
	  }
	  
	  public Object getParent(Object element) {
	    return ((Node) element).getParent();
	  }
	  
	  public boolean hasChildren(Object element) {
	    return ((Node) element).getSubCategories() != null;
	  }
	  
	  public Object[] getElements(Object inputElement) {
	    if (inputElement != null && inputElement instanceof Vector) {
	      return ((Vector) inputElement).toArray();
	    }
	    return new Object[0];
	  }
	  
	  public void dispose() {
	  }
	  
	  public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
	  }
	  
	}
	
