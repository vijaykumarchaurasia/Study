package com.navistar.datadictionary.editor;

import java.awt.event.KeyAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.swing.CellEditor;
import javax.swing.event.CellEditorListener;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.operations.*;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.ConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.DefaultNatTableStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IEditableRule;
import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.data.ListDataProvider;
import org.eclipse.nebula.widgets.nattable.edit.CellEditorCreatedEvent;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.edit.command.EditCellCommand;
import org.eclipse.nebula.widgets.nattable.grid.GridRegion;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultColumnHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultCornerDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultRowHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.layer.ColumnHeaderLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.CornerLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.DefaultGridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.GridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.RowHeaderLayer;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayerListener;
import org.eclipse.nebula.widgets.nattable.layer.LayerUtil;
import org.eclipse.nebula.widgets.nattable.layer.event.CellVisualChangeEvent;
import org.eclipse.nebula.widgets.nattable.layer.event.CellVisualUpdateEvent;
import org.eclipse.nebula.widgets.nattable.layer.event.ILayerEvent;
import org.eclipse.nebula.widgets.nattable.persistence.command.DisplayPersistenceDialogCommandHandler;
import org.eclipse.nebula.widgets.nattable.selection.RowSelectionProvider;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.selection.event.CellSelectionEvent;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.viewport.ViewportLayer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.ControlListener;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IReusableEditor;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPartConstants;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.menus.IMenuService;
import org.eclipse.ui.operations.RedoActionHandler;
import org.eclipse.ui.operations.UndoActionHandler;
import org.eclipse.ui.operations.UndoRedoActionGroup;

import com.navistar.datadictionary.constant.DataDictionaryConstant;
import com.navistar.datadictionary.constant.MyConstants;
import com.navistar.datadictionary.model.Department;
import com.navistar.datadictionary.model.DepartmentDAO;
import com.navistar.datadictionary.model.TableCell;
import com.navistar.datadictionary.provider.DepartmentColumnPropertyAccessor;
import com.navistar.datadictionary.provider.DepartmentHeaderDataProvider;


//IReusableEditor: Can setting new input value for this Editor.
public class DeptEditor extends AbstractBaseEditor implements IReusableEditor {

public static final String ID = "deptEditor";
private Integer deptId;
private Text text_deptNo;
private Text text_deptName;
private Text text_location;
public static NatTable natTable;
private ObjectUndoContext undoContext;
private UndoRedoActionGroup undoRedoActionGroup;
private CellSelectionEvent cellEvent1;
private CellVisualChangeEvent cellEvent2;
private CellVisualUpdateEvent cellEvent3;
private int rowIndex;
private int columnIndex;
private Object cellData;
public static HashMap<TableCell, Object> cellStackForUndo = new LinkedHashMap<>();
public static IDataProvider bodyDataProvider;
public static int editCount = 1;
public DeptEditor() {
}

@PostConstruct
@Override
public void createPartControl2(Composite parent) {
	 
	/*IWorkbench workbench = PlatformUI.getWorkbench();
    IUndoContext myUndoContext= workbench.getOperationSupport().getUndoContext();
    
    UndoActionHandler undoHandler = new UndoActionHandler(getSite(), myUndoContext);
    //getEditorSite().getActionBars().setGlobalActionHandler(ActionFactory.UNDO.getId(), undoHandler);
    
	IActionBars actionBars = getEditorSite().getActionBars();
	actionBars.setGlobalActionHandler(ActionFactory.UNDO.getId(), undoHandler);
	//actionBars.updateActionBars();
	new UndoRedoActionGroup(getSite(), myUndoContext, false);
	actionBars.updateActionBars();*/
	
		
   // property names of the Department class
   String[] propertyNames = { "deptId", "deptNo", "deptName", "location" };
   
   // mapping from property to label, needed for column header labels
   Map<String, String> propertyToLabelMap = new HashMap<String, String>();
   propertyToLabelMap.put("deptId", "Department_ID");
   propertyToLabelMap.put("deptNo", "Department_No");
   propertyToLabelMap.put("deptName", "Department_Name");
   propertyToLabelMap.put("location", "Department_Loc");

// create the data provider
   //IColumnPropertyAccessor<Department> columnPropertyAccessor = new ReflectiveColumnPropertyAccessor<Department>(propertyNames);
   IColumnPropertyAccessor<Department> columnPropertyAccessor = new DepartmentColumnPropertyAccessor();

   bodyDataProvider =
           new ListDataProvider<Department>(
           		DepartmentDAO.listDepartment(), columnPropertyAccessor);
   
   final DataLayer bodyDataLayer = new DataLayer(bodyDataProvider);
   DepartmentHeaderDataProvider headerDataProvider = new DepartmentHeaderDataProvider();
   
   SelectionLayer selectionLayer = new SelectionLayer(bodyDataLayer);
   ViewportLayer viewportLayer = new ViewportLayer(selectionLayer);
   
   // build the column header layer stack
   IDataProvider columnHeaderDataProvider = new DefaultColumnHeaderDataProvider(propertyNames, propertyToLabelMap);
   DataLayer columnHeaderDataLayer = new DataLayer(columnHeaderDataProvider);
   ILayer columnHeaderLayer = new ColumnHeaderLayer(columnHeaderDataLayer,
		    										viewportLayer,
		    										selectionLayer);
		
   // build the row header layer stack
   IDataProvider rowHeaderDataProvider = new DefaultRowHeaderDataProvider(bodyDataProvider);
   DataLayer rowHeaderDataLayer = new DataLayer(rowHeaderDataProvider, 40, 20);
   ILayer rowHeaderLayer = new RowHeaderLayer(rowHeaderDataLayer,viewportLayer,selectionLayer);
   
   // build the corner layer stack
   IDataProvider cornerDataProvider = new DefaultCornerDataProvider(columnHeaderDataProvider,rowHeaderDataProvider);
   DataLayer cornerDataLayer = new DataLayer(cornerDataProvider);
   ILayer cornerLayer = new CornerLayer(cornerDataLayer,rowHeaderLayer,columnHeaderLayer);

   // create the grid layer composed with
   // the prior created layer stacks
   GridLayer gridLayer = new GridLayer(viewportLayer,columnHeaderLayer,rowHeaderLayer,cornerLayer);
   //DefaultGridLayer gridLayer = new DefaultGridLayer(bodyDataProvider, headerDataProvider);
   natTable = new NatTable(parent, gridLayer, false);
  
   natTable.addConfiguration(new DefaultNatTableStyleConfiguration());
   natTable.addConfiguration(new AbstractRegistryConfiguration() {

       @Override
       public void configureRegistry(IConfigRegistry configRegistry) {
           configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,
                   IEditableRule.ALWAYS_EDITABLE);
           
         
       }
   });

   natTable.configure();
   GridDataFactory.fillDefaults().grab(true, true).applyTo(natTable);
   
  natTable.addLayerListener(new ILayerListener() {		
			@Override
			public void handleLayerEvent(ILayerEvent event) {
				//IUndoableOperation operation = PlatformUI.getWorkbench().getOperationSupport().getOperationHistory();
				//OperationHistoryFactory.getOperationHistory().add(new undo);
				//System.out.println("event type : "+event.getClass().getSimpleName());
				if(event instanceof CellSelectionEvent)
				{
					//System.out.println("Event : " + event);
					cellEvent1 = (CellSelectionEvent) event;
					rowIndex = cellEvent1.getRowPosition();
					columnIndex = cellEvent1.getColumnPosition();
					
					cellData = natTable.getDataValueByPosition(columnIndex, rowIndex);
					
					if((cellData != null) && (editCount <= DataDictionaryConstant.MAXSTACKSIZE))
					{
						cellStackForUndo.put(new TableCell(rowIndex, columnIndex), cellData);
						editCount++;
					}
					else if((cellData != null) && (editCount > DataDictionaryConstant.MAXSTACKSIZE))
					{
						//System.out.println("Removing eldest entry key : " + cellStackForUndo.keySet().toArray()[0]);
						if(cellStackForUndo.size()>0)
						{
							Object sample = cellStackForUndo.remove(cellStackForUndo.keySet().toArray()[0]);
						}
						
						cellStackForUndo.put(new TableCell(rowIndex, columnIndex), cellData);
						
						editCount++;
					}

				}
				if(event instanceof CellVisualChangeEvent)
				{
					cellEvent2 = (CellVisualChangeEvent) event;
					columnIndex = cellEvent2.getColumnPosition();
					rowIndex = cellEvent2.getRowPosition();
					cellData = natTable.getDataValueByPosition(columnIndex, rowIndex);
					//System.out.println("CellVisualChangeEvent		:	" + cellData);
					//System.out.println("New Cell Data : " + cellData);
				}
				//natTable.refresh();
			}
  });
  
  //selectionLayer = new SelectionLayer(bodyDataLayer);
 
  /* IHandlerService handlerService = (IHandlerService) getSite().getService(IHandlerService.class);
   //handlerService.activateHandler("org.eclipse.ui.edit.undo", undoHandler);
   try {
       		handlerService.executeCommand("org.eclipse.ui.edit.undo", null);
       }
   catch (Exception ex) {
           throw new RuntimeException("org.eclipse.ui.edit.undo not found");
           // Give message
       }*/
   
}

@Override
public void doSave(IProgressMonitor monitor) {
    /*try {
        String deptNo = this.text_deptNo.getText();
        String deptName = this.text_deptName.getText();
        String location = this.text_location.getText();
        if (this.deptId != null) {
            Department dept = DepartmentDAO.updateDepartment(deptId,
                    deptNo, deptName, location);

            this.setInput(new DeptEditorInput(dept));
            this.setDirty(false);
            this.firePropertyChange(MyConstants.EDITOR_DATA_CHANGED);
        } else {
            Department dept = DepartmentDAO.insertDepartment(deptNo,
                    deptName, location);
            this.setInput(new DeptEditorInput(dept));
            this.setDirty(false);
            this.firePropertyChange(MyConstants.EDITOR_DATA_CHANGED);
        }
        
        
    } catch (Exception e) {
        MessageDialog.openError(this.getSite().getShell(), "Error",
                e.getMessage());
        e.printStackTrace();
    }*/
}

@Override
protected Control[] registryDirtyControls() {
	return null;
    /*return new Control[] { this.text_deptName, this.text_deptNo,
            this.text_location };*/
}

@Override
public void showData() {
   /* DeptEditorInput ip = (DeptEditorInput) this.getEditorInput();
    Department dept = ip.getDept();

    this.deptId = dept.getDeptId();
    this.text_deptName.setText(dept.getDeptName() == null ? "" : dept
            .getDeptName());
    this.text_deptNo.setText(dept.getDeptNo() == null ? "" : dept
            .getDeptNo());
    this.text_location.setText(dept.getLocation() == null ? "" : dept
            .getLocation());
    // Clear dirty.
    this.setDirty(false);*/
}


// Override setInput(..) with public (IReusableEditor)
@Override
public void setInput(IEditorInput input) {
    super.setInput(input);
    firePropertyChange(IWorkbenchPartConstants.PROP_INPUT);
}

public String getDeptInfo() {
	return null;
   /* DeptEditorInput input = (DeptEditorInput) this.getEditorInput();
    Department dept = input.getDept();
    if (dept == null) {
        return "";
    }
    String info = dept.getDeptNo() + " - " + dept.getDeptName() + " - "
            + dept.getLocation();
    return info;*/
}

@Override
public Object getAdapter(Class arg0) {
	// TODO Auto-generated method stub
	return null;
}

}