package com.navistar.datadictionary.other;

import java.util.Vector;

public class Node implements Comparable<Node>{
	  private String name;
	  private Vector subCategories;
	  private Node parent;
	  
	  public Node(String name, Node parent) {
	    this.name = name;
	    this.parent = parent;
	    if (parent != null)
	      parent.addSubCategory(this);
	  }
	  
	  public Vector getSubCategories() {
	    return subCategories;
	  }
	  
	  private void addSubCategory(Node subcategory) {
	    if (subCategories == null)
	      subCategories = new Vector();
	    if (!subCategories.contains(subcategory))
	      subCategories.add(subcategory);
	  }
	  
	  public String getName() {
	    return name;
	  }
	  
	  public Node getParent() {
	    return parent;
	  }
	  
	  @Override
	  public int compareTo(Node compareNode) {
		return 0;
	  
		 // return this.getName()-compareNode.getName();
	  }  	
}
