package com.navistar.datadictionary.other;

import java.util.Comparator;

public class NodeComparator implements Comparator<Node>{

	//Comparator to compare node objects
	@Override
	public int compare(Node node1, Node node2) {
		return (node1.getName().toLowerCase()).compareTo(node2.getName().toLowerCase());
	}

}
