package com.navistar.datadictionary.service;

import java.util.Arrays;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;

import com.navistar.datadictionary.model.Category;

public class InputColumnPropertyAccessorService implements IColumnPropertyAccessor<Category> {

	 private static final List<String> propertyNames =
		        Arrays.asList("category","name","description","dataType","min","max","unit","complexity","dimensions","dimensionsMode","sampleTime","samplingMode","initialValue");
	 
	 @Override
	    public Object getDataValue(Category inputObject, int columnIndex) {
	        switch (columnIndex) {
	            case 0:
	                return inputObject.getCategory();
	            case 1:
	                return inputObject.getName();
	            case 2:
	                return inputObject.getDescription();
	            case 3:
	                return inputObject.getDataType();
	            case 4:
	                return inputObject.getMin();
	            case 5:
	                return inputObject.getMax();
				case 6:
	                return inputObject.getUnit();
				case 7:
	                return inputObject.getComplexity();
				case 8:
					inputObject.setDimensions("dimensions");
	                return inputObject.getDimensions();
				case 9:
	                return inputObject.getDimensionsMode();
				case 10:
	                return inputObject.getSampleTime();
				case 11:
	                return inputObject.getSamplingMode();
	            case 12:
	                return inputObject.getInitialValue();
	                		               
	            }
	        return inputObject;
	    }

	    @Override
	    public void setDataValue(Category inputObject, int columnIndex, Object newValue) {
	        switch (columnIndex) {
				
				case 0:
					inputObject.setCategory((String) newValue);
					break;
	            case 1:
	                inputObject.setName((String) newValue);
					break;
	            case 2:
	                inputObject.setDescription((String) newValue);
					break;
	            case 3:
	                inputObject.setDataType((String) newValue);
					break;
	            case 4:
	                inputObject.setMin((String) newValue);
					break;
	            case 5:
	                inputObject.setMax((String) newValue);
					break;
				case 6:
	                inputObject.setUnit((String) newValue);
					break;
				case 7:
	                inputObject.setComplexity((String) newValue);
					break;
				case 8:
	               // inputObject.setDimensions((String) newValue);
					 inputObject.setDimensions("dimensions");
					break;
				case 9:
	                inputObject.setDimensionsMode((String) newValue);
					break;
				case 10:
	                inputObject.setSampleTime((String) newValue);
					break;
				case 11:
	                inputObject.setSamplingMode((String) newValue);
					break;
	            case 12:
	                inputObject.setInitialValue((String) newValue);
					break;
	            
	        }
	    }

	    @Override
	    public int getColumnCount() {
	        return 13;
	    }

	    @Override
	    public String getColumnProperty(int columnIndex) {
	        return propertyNames.get(columnIndex);
	    }

	    @Override
	    public int getColumnIndex(String propertyName) {
	        return propertyNames.indexOf(propertyName);
	    }

		
}
