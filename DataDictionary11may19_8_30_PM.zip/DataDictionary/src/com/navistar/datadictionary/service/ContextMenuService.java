package com.navistar.datadictionary.service;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.LinkedHashMap;
import java.util.Vector;

import org.eclipse.core.runtime.AssertionFailedException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.categories.editor.InputEditor;
import com.navistar.datadictionary.categories.editorinput.CategoryEditorInput;
import com.navistar.datadictionary.constant.DataDictionaryConstant;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.other.Node;
import com.navistar.datadictionary.view.ProjectExplorerView;

public class ContextMenuService {

	//It will contain index of open project
	public static int index = 0; 
	public void performContextMenuAction(String actionName,TreeViewer viewer)
	{		
		ImportProjectStructureService importService = new ImportProjectStructureService();
		try {

			if (actionName.equals(DataDictionaryConstant.OPEN_PROJECT)) {	
				Shell shell = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell();
				boolean dialogReturnValue = false;
				String firstProjectOpen = DataDictionaryConstant.EMPTY_STRING;
				//add popup if any project is open
				for(String projectPath : ProjectExplorerView.projectAndStatusMap.keySet())
				{
					if(ProjectExplorerView.projectAndStatusMap.get(projectPath).getStatus()==1)
					{
						dialogReturnValue = MessageDialog.openConfirm(shell, "Warning", DataDictionaryConstant.OPEN_PROJECT_MESSAGE);
						firstProjectOpen = DataDictionaryConstant.EMPTY_STRING;
						break;
					}
					firstProjectOpen = DataDictionaryConstant.PROJECT_OPEN_FIRST_TIME;
				}
				
				if((dialogReturnValue) || (DataDictionaryConstant.PROJECT_OPEN_FIRST_TIME.equals(firstProjectOpen)))
				{
					String projectName = enableProject(viewer);
					Tree tree = viewer.getTree();
					int treeItemCount = tree.getItems().length;
					for(int i=0;i<treeItemCount;i++)
					{
						if(projectName.equals(tree.getItem(i).getText()))
							importService.updateProjectStatus(projectName, DataDictionaryConstant.OPEN_PROJECT_STATUS);
						else
							importService.updateProjectStatus(tree.getItem(i).getText(), DataDictionaryConstant.CLOSE_PROJECT_STATUS);
					}
				}
				
			}			
			else if(actionName.equals(DataDictionaryConstant.CLOSE_PROJECT)){	
				Tree tree = viewer.getTree();
				int treeItemCount = tree.getItems().length;
				//Close/disable all the project
				disableProject(viewer);	
				for(int i=0;i<treeItemCount;i++)
				{
					importService.updateProjectStatus(tree.getItem(i).getText(), DataDictionaryConstant.CLOSE_PROJECT_STATUS);
				}
				
			}
			else if(actionName.equals(DataDictionaryConstant.REMOVE_PROJECT)) {

				TreeItem[] viewerItem= viewer.getTree().getSelection();
				viewerItem[0].dispose();				
			}
			else if(actionName.equals(DataDictionaryConstant.OPEN_COMPONENT)) {
				IStructuredSelection thisSelection = (IStructuredSelection) viewer.getSelection();
				Node selectedNode = (Node) thisSelection.getFirstElement();
				Node parentNode = selectedNode;

				while (null != parentNode.getParent()) {
					parentNode = parentNode.getParent();
				}
				displayComponentCategories();			
			}
			else if(actionName.equals(DataDictionaryConstant.RESOLVE_INCONSISTENCY)) {

			}
			else if(actionName.equals(DataDictionaryConstant.CHECK_COMPONENT_INPUTS)) {

			}
		}
		catch (AssertionFailedException assertionFailedException) {
			Shell shell=new Shell();
			MessageDialog.openInformation(shell, "Warning", "First import a project");
		}   
		catch (Exception e) {

		}
	}

	public void displayComponentCategories() {
		/*IWorkbench workbench = PlatformUI.getWorkbench();
		IWorkbenchWindow activeWindow = workbench.getActiveWorkbenchWindow();
		IWorkbenchPage activePage = activeWindow.getActivePage();
		JsonArrayProvider jsonArrayProvider = new JsonArrayProvider();
		List<CategoryEditorInput> categoryEditorInputList;
		JsonElement jsonElement = jsonArrayProvider.getJsonArrayFromFile();
		categoryEditorInputList = new CopyOnWriteArrayList<CategoryEditorInput>();

		for (JsonElement jsonElementArr : jsonElement.getAsJsonArray()) {
			CategoryEditorInput categoryEditorInput = new CategoryEditorInput(jsonElementArr);
			categoryEditorInputList.add(categoryEditorInput);
		}

		boolean found = false;
		// Opening Editor references
		IEditorReference[] eRefs = activePage.getEditorReferences();
		for (IEditorReference ref : eRefs) {
			IEditorPart editorPart = ref.getEditor(false);
			if (editorPart != null && editorPart instanceof InputEditor) {
				// Restore
				InputEditor editor = (InputEditor) ref.getEditor(true);
				found = true;

				boolean saved = true;

				// If editor is dirty, save it.
				if (editor.isDirty()) {
					saved = activePage.saveEditor(editor, true);
				}
				if (saved) {
					// Reset input for InputEditor.
					CategoryEditorInput inputEditor = (CategoryEditorInput) editor.getEditorInput();

					Iterator<CategoryEditorInput> it = categoryEditorInputList.iterator();
					while (it.hasNext()) {
						CategoryEditorInput categoryEditorInput = (CategoryEditorInput) it.next();
						if (categoryEditorInput.getName().equals(inputEditor.getName())) {
							categoryEditorInputList.remove(categoryEditorInput);
						}
					}
					try {
						activePage.reuseEditor(editor, inputEditor);
						editor.showData();
					} catch (Exception e) {
						e.printStackTrace();
					}

				}
			}
		}

		if (!found) {
			if (categoryEditorInputList.size() > 0) {
				Iterator<CategoryEditorInput> it = categoryEditorInputList.iterator();
				while (it.hasNext()) {
					CategoryEditorInput categoryEditorInput = it.next();

					try {
						activePage.openEditor(categoryEditorInput, InputEditor.ID);
					} catch (PartInitException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}

		} else {
			if (categoryEditorInputList.size() > 0) {
				Iterator<CategoryEditorInput> it = categoryEditorInputList.iterator();
				while (it.hasNext()) {
					CategoryEditorInput categoryEditorInput = it.next();

					try {
						activePage.openEditor(categoryEditorInput, InputEditor.ID);
					} catch (PartInitException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}

		}*/
	}

	public String enableProject(TreeViewer viewer)
	{
		Tree tree = viewer.getTree();
		IStructuredSelection selected = (IStructuredSelection) viewer.getSelection();
		Node selectNode = (Node) selected.getFirstElement();

		TreeItem[] item = tree.getSelection();
		TreeItem[] item2 = viewer.getTree().getItems();
		String projectName = item[0].getText();
		int i = 0;
		for(TreeItem it:item2) {
			if(projectName.equals(it.getText())) {
				index = i;
				break;
			}
			i=i+1;
		}

		viewer.setExpandedState(selectNode, !viewer.getExpandedState(selectNode));
		viewer.refresh();
		//Disable all the project logic start here
		for(i=0;i<item2.length;i++)
		{
			if(i!=index) {
				tree.getItem(i).setItemCount(0);
			}

		}
		return projectName;
	}

	public void disableProject(TreeViewer viewer)
	{
		Tree tree = viewer.getTree();
		for(int i=0;i<tree.getItems().length;i++)
		{
			tree.getItem(i).setItemCount(DataDictionaryConstant.CLOSE_PROJECT_TREEITEM_COUNT);
		}
	}

	public void loadProjectStatusFromWorkspace(TreeViewer viewer,Vector<Node> nodes)
	{
		LinkedHashMap<String, Project> projectStatusMap = ProjectExplorerView.projectAndStatusMap;
		Tree tree = viewer.getTree();
		TreeItem[] allTreeItems = viewer.getTree().getItems();

		int flag=0;
		int i=0;
		String openProjectName = null;
		Node openNode = null ;
		for(String key : projectStatusMap.keySet())
		{
			if(DataDictionaryConstant.OPEN_PROJECT_STATUS == projectStatusMap.get(key).getStatus())
			{
				String folders[] = key.split("\\\\");
				openProjectName = folders[folders.length-1];
				flag=1;
				break;
			}				
		}
		
		if(flag == 1)
		{
			for(TreeItem treeItem1 : allTreeItems) {
				if(openProjectName.equals(treeItem1.getText())) {
					index = i;
					break;
				}
				i=i+1;
			}
			openNode = nodes.get(index);
			viewer.setExpandedState(openNode, !viewer.getExpandedState(openNode));
			viewer.refresh();
			//Disable all the project logic start here
			for(i=0;i<allTreeItems.length;i++)
			{
				if(i!=index) 
				{
					tree.getItem(i).setItemCount(DataDictionaryConstant.CLOSE_PROJECT_TREEITEM_COUNT);
				}
			}

		}	
		else
		{
			for(i=0;i<allTreeItems.length;i++)
			{
				tree.getItem(i).setItemCount(0);
			}
		}

	}
}
