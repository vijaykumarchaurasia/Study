package com.navistar.datadictionary.service;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Shell;

import com.navistar.datadictionary.constant.DataDictionaryConstant;
import com.navistar.datadictionary.util.FileUtility;

public class DirectoryDialogService {

	String path;
	
	/**
	 * Function used to open directory dialog which allows user to select a required folder
	 * @param shell
	 * @return
	 */
	public String openDirectoryDialog(Shell shell) {
		DirectoryDialog dialog = new DirectoryDialog(shell);
        path = dialog.open();
        boolean directoryStatus;

        if (path != null) {
        	directoryStatus = onOkClick();
        	if(directoryStatus == true)
        		return path;
        	else
        		return DataDictionaryConstant.INVALID;
        }
        else
        	return null;		
	}
	
	/**
	 * Function used for "OK" click of DirectoryDialog
	 * @return 
	 */
	private boolean onOkClick() {
		 List<String> slddComponent = new ArrayList<>();
		 slddComponent = new FileUtility().getComponentList(path);
						
		 if(slddComponent.isEmpty()) 
		 {
			 return false;
		 }
		 else 
		 {		
			 return true;
		 }
	}
}
