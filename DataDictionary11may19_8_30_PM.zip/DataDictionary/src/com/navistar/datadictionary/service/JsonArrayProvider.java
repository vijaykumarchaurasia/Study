package com.navistar.datadictionary.service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.navistar.datadictionary.communication.MatlabDataRequest;
import com.navistar.datadictionary.model.Category;

public class JsonArrayProvider {

	public JsonElement getJsonArrayFromFile()
	{
		JsonParser parser = new JsonParser();
		JsonElement jsonArrayFromFile = null;
		String projectName = "";
		//Object componentName = "aeafm.sldd";
		String componentName = "aeafm.sldd";	
		
			MatlabDataRequest matlabDataRequest = new MatlabDataRequest();
		try {
			
			//matlabDataRequest.loadSlddData(projectName, componentName);
			JsonElement obj = parser.parse(new FileReader("D:\\navistar_SVN_updated\\DataDictionary\\JSON_Format_Category.json"));			
			System.out.println(obj.toString()); 
			
			jsonArrayFromFile = obj;
			
			
		} catch (JsonIOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonSyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonArrayFromFile;
		
	}
}
