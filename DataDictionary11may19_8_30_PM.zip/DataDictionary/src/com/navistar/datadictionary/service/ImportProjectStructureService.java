package com.navistar.datadictionary.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.other.Node;
import com.navistar.datadictionary.util.FileUtility;
import com.navistar.datadictionary.view.ProjectExplorerView;

public class ImportProjectStructureService {

	//all imported project component
	List<String> allImportedcomponentList = new ArrayList<>();	
	//all imported project component path and name
	Map<String, String> slddPathMap = new LinkedHashMap<>();
	//all imported project parent and its component
	public static Map<String, Map<String, String>> projectMap = new LinkedHashMap<>();	 

	/**
	 * Function used to maintain imported project structure for current instance of application
	 * @param filePath
	 * @return
	 */
	public List<String> maintainImportedProject(String filePath)
	{
		//current imported project component
		List<String> currentImportedcomponentList = new ArrayList<>();		

		File parentFileObject = new File(filePath);
		String parentElement = parentFileObject.getName();

		FileUtility fileUtils = new FileUtility();
		currentImportedcomponentList = fileUtils.getComponentList(filePath);

		slddPathMap = FileUtility.slddPathMap;

		Map<String,String> currentComponentPath_Name = new LinkedHashMap<String, String>();
		for(String key : slddPathMap.keySet())
		{
			String value = slddPathMap.get(key);

			for(String compName : currentImportedcomponentList)
			{
				if(compName.equals(value))
				{
					currentComponentPath_Name.put(key, compName);
				}
			}
		}
		projectMap.put(parentElement, currentComponentPath_Name);

		return currentImportedcomponentList;
	}

	/**
	 * Function used to maintain the status of every project
	 * @param projectAndStatusMap
	 * @param projectPath
	 * @param status
	 * @return
	 */
	public LinkedHashMap<String, Project> setProjectandStaus(LinkedHashMap<String,Project> projectAndStatusMap,String projectPath,int status)
	{	
		if(projectAndStatusMap.containsKey(projectPath))
		{
			projectAndStatusMap.put(projectPath,new Project(projectPath, status));
		}
		else
		{
			projectAndStatusMap.put(projectPath,new Project(projectPath, status));
		}
		return projectAndStatusMap;
	}
	/**
	 * Function is used to update a imported project status as per open, close or remove
	 * @param projectName
	 * @param status
	 */
	public void updateProjectStatus(String projectName, int status)
	{
		LinkedHashMap<String, Project> projectMap = ProjectExplorerView.projectAndStatusMap;
		for(String projectPathAsKey : projectMap.keySet())
		{
			String folder[] = projectPathAsKey.split("\\\\");
			String projectToBeCompare = folder[folder.length-1];
			if(projectToBeCompare.equals(projectName))
			{
				ProjectExplorerView.projectAndStatusMap.put(projectPathAsKey, new Project(projectPathAsKey, status));
			}
		}
	}
	/**
	 * Function is used to get project status using project name
	 * @param projectName
	 * @return
	 */
	public int getProjectStatus(String projectName)
	{
		int status=0;
		LinkedHashMap<String, Project> projectMap = ProjectExplorerView.projectAndStatusMap;
		for(String projectPathAsKey : projectMap.keySet())
		{
			String folder[] = projectPathAsKey.split("\\\\");
			String projectToBeCompare = folder[folder.length-1];
			if(projectToBeCompare.equals(projectName))
			{
				status = projectMap.get(projectPathAsKey).getStatus();
			}
		}
		return status;
	}

	public Node createTreeStructure(String filePath,int importStatus)
	{
		List<String> currentImportedcomponentList = new ArrayList<>();
		File parentFileObject = new File(filePath);
		String parentElement = parentFileObject.getName();

		currentImportedcomponentList = maintainImportedProject(filePath);

		//sort alphabetically
		Collections.sort(currentImportedcomponentList);

		Node category = new Node(parentElement, null);

		for(String compName : currentImportedcomponentList)
		{
			new Node(compName, category);
		}
		return category; 
	}
}
