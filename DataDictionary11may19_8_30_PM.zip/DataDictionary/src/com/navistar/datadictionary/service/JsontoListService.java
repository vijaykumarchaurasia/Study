package com.navistar.datadictionary.service;

import java.lang.reflect.Type;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.model.Category;

public class JsontoListService {
	
	public static List<Category> listInputs(JsonArray jsonArray) {
		
		  Gson gson = new Gson();
		//  JsonParser parser = new JsonParser();
//		  String newArray = jsonArray.toString().replace("NULL", "");
//		  jsonArray = (JsonArray)parser.parse(newArray);
		  Type type = new TypeToken<List<Category>>(){}.getType();		  
	      return gson.fromJson(jsonArray, type);
	}

}
