package com.navistar.datadictionary.service;

import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.edit.config.DefaultEditConfiguration;
import org.eclipse.nebula.widgets.nattable.grid.GridRegion;
import org.eclipse.nebula.widgets.nattable.grid.layer.ColumnHeaderLayer;
import org.eclipse.nebula.widgets.nattable.hideshow.ColumnHideShowLayer;
import org.eclipse.nebula.widgets.nattable.hideshow.command.ColumnHideCommand;
import org.eclipse.nebula.widgets.nattable.hideshow.command.ColumnHideCommandHandler;
import org.eclipse.nebula.widgets.nattable.layer.CompositeLayer;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.LabelStack;
import org.eclipse.nebula.widgets.nattable.layer.cell.IConfigLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.painter.layer.NatGridLayerPainter;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.viewport.ViewportLayer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class NatTableService {
	JsonElement jsonElementofDataObjects;

	public NatTable displayNatTable(Composite parent,JsonElement jsonElementofDataObjects)
	{
		//JsonArrayProvider jsonArrayProviderObject = new JsonArrayProvider();
		this.jsonElementofDataObjects = jsonElementofDataObjects;//jsonArrayProviderObject.getJsonArrayFromFile();
		
		JsonDataProvider jsonDataProvider = new JsonDataProvider(jsonElementofDataObjects.getAsJsonArray(),
                new JsonColumnAccessor(jsonElementofDataObjects));
		
		
	        
		DataLayer dataLayer = new DataLayer(jsonDataProvider);
		
		dataLayer.setConfigLabelAccumulator(new IConfigLabelAccumulator() {
		    @Override
		    public void accumulateConfigLabels(
		        LabelStack configLabels, int columnPosition, int rowPosition) {

		      JsonElement  p = jsonDataProvider.getRowObject(rowPosition);
		      JsonObject obj = p.getAsJsonObject();
		      obj.addProperty("category", "Vijay");
		      p = obj;
		      JsonElement col = obj.get("category");
		      
		        if (p != null) {
		            /*configLabels.addLabel(
		                p.getGender().equals(Gender.FEMALE) ? FEMALE_LABEL : MALE_LABEL);*/
		        	configLabels.addLabel(
		        			col.getAsString());
		            jsonDataProvider.setDataValue(columnPosition, rowPosition, col);
		  
		        }
		    }
		});
        SelectionLayer selectionLayer = new SelectionLayer(dataLayer);
        ViewportLayer viewportLayer = new ViewportLayer(selectionLayer);
        
           
      
        IDataProvider headerDataProvider = new JsonColumnHeaderDataProvider(jsonElementofDataObjects);
	    DataLayer headerDataLayer = new DataLayer(headerDataProvider);
	    
        ILayer columnHeaderLayer = new ColumnHeaderLayer(headerDataLayer, viewportLayer, selectionLayer);
          
        CompositeLayer compositeLayer = new CompositeLayer(1, 2);
        compositeLayer.setChildLayer(GridRegion.COLUMN_HEADER, columnHeaderLayer, 0, 0);
        compositeLayer.setChildLayer(GridRegion.BODY, viewportLayer, 0, 1);
        

        compositeLayer.addConfiguration(new DefaultEditConfiguration());
        NatTable natTable = new NatTable(parent,compositeLayer,false); 
        
        // To fill the layout
        
        NatGridLayerPainter layerPainter = new NatGridLayerPainter(natTable);
        natTable.setLayerPainter(layerPainter);
        
        int columPosition = selectionLayer.getColumnCount()-13;
        System.out.println(columPosition);
       
        natTable.doCommand(new ColumnHideCommand(columnHeaderLayer,columPosition ));
        	//	System.out.println(((NatTable) headerDataLayer.getDataProvider()).getColumnIndexByPosition(0));
               // System.out.println(headerDataLayer.getColumnIndexByPosition(0));
               // System.out.println(headerDataLayer.getColumnCount());
		return natTable;
		
	}
}
