package com.navistar.datadictionary.service;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.data.ListDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultColumnHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultCornerDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultRowHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.layer.ColumnHeaderLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.CornerLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.GridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.RowHeaderLayer;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.viewport.ViewportLayer;
import org.eclipse.swt.widgets.Composite;

import com.google.gson.JsonElement;
import com.navistar.datadictionary.model.Category;

public class NatTableDisplayServise {
	
	private IColumnPropertyAccessor<Category> columnPropertyAccessor = new InputColumnPropertyAccessorService();
	private String[] propertyNames = { "name", "description", "dataType", "min", "max", "unit", "complexity" , "dimensions", "dimensionsMode", "dimensionsMode", "sampleTime" 
			, "samplingMode","initialValue"};
	
	//static JsonArray jsonArray;
	private NatTable natTable;
	//Composite parent;
	
	public NatTable displayNatTable(Composite parent,JsonElement jsonElement)
	{
		List<Category> list = new ArrayList<>();
		list = JsontoListService.listInputs(jsonElement.getAsJsonArray());
		IDataProvider bodyDataProvider = new ListDataProvider<Category>(list, columnPropertyAccessor);
		   
		   final DataLayer bodyDataLayer = new DataLayer(bodyDataProvider);
		   //DepartmentHeaderDataProvider headerDataProvider = new DepartmentHeaderDataProvider();
		   
		   SelectionLayer selectionLayer = new SelectionLayer(bodyDataLayer);
		   ViewportLayer viewportLayer = new ViewportLayer(selectionLayer);
		   
		   // build the column header layer stack
		   //IDataProvider columnHeaderDataProvider = new DefaultColumnHeaderDataProvider(propertyNames, propertyToLabelMap);
		   IDataProvider columnHeaderDataProvider = new DefaultColumnHeaderDataProvider(propertyNames);
		   DataLayer columnHeaderDataLayer = new DataLayer(columnHeaderDataProvider);
		   ILayer columnHeaderLayer = new ColumnHeaderLayer(columnHeaderDataLayer,viewportLayer,selectionLayer);
				
		   // build the row header layer stack
		   IDataProvider rowHeaderDataProvider = new DefaultRowHeaderDataProvider(bodyDataProvider);
		   DataLayer rowHeaderDataLayer = new DataLayer(rowHeaderDataProvider, 40, 20);
		   ILayer rowHeaderLayer = new RowHeaderLayer(rowHeaderDataLayer,viewportLayer,selectionLayer);
		   
		   // build the corner layer stack
		   IDataProvider cornerDataProvider = new DefaultCornerDataProvider(columnHeaderDataProvider,rowHeaderDataProvider);
		   DataLayer cornerDataLayer = new DataLayer(cornerDataProvider);
		   ILayer cornerLayer = new CornerLayer(cornerDataLayer,rowHeaderLayer,columnHeaderLayer);

		   // create the grid layer composed with the prior created layer stacks
		   GridLayer gridLayer = new GridLayer(viewportLayer, columnHeaderLayer, rowHeaderLayer, cornerLayer);
		   //DefaultGridLayer gridLayer = new DefaultGridLayer(bodyDataProvider, headerDataProvider);
		   natTable = new NatTable(parent, gridLayer, false);	
		   
		   return natTable;
		
	}

}
