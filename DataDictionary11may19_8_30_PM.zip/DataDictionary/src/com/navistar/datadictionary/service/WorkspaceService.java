package com.navistar.datadictionary.service;

import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.util.FileUtility;
import com.navistar.datadictionary.view.ProjectExplorerView;

public class WorkspaceService {

	/**
	 * Function will return already imported projects and their status
	 * @param workspacePath
	 * @return
	 */
	public LinkedList<Project> getWorkspaceHistory(String workspacePath)
	{
		FileUtility fileUtils = new FileUtility();
		Gson gsonObject = new Gson();
		LinkedList<Project>projectList = new LinkedList<>();
		JsonElement jsonElement = fileUtils.readFromJsonFile("D:/_Navistar Data Dictionary/workspace.json");
		
		if(jsonElement!= null)
		{
			Type type = new TypeToken<LinkedList<Project>>(){}.getType();
			projectList= gsonObject.fromJson(jsonElement, type);
			
		}
		return projectList;		
	}
	/**
	 * Function used to save current status of workspace
	 * @param workspacePath
	 * @return
	 */
	public boolean saveWorkspaceHistory(String workspacePath)
	{
		LinkedHashMap<String, Project> projectAndStatusMap = ProjectExplorerView.projectAndStatusMap;
		Gson gsonObject = new Gson();
		FileUtility fileUtils = new FileUtility();
		//Convert project objects into json object
		String projectListJson = gsonObject.toJson(projectAndStatusMap.values());
		
		boolean writeStatus = fileUtils.writeIntoJsonFile(projectListJson, "D:/_Navistar Data Dictionary/workspace.json");
		
		return writeStatus;	
	}
	
}
