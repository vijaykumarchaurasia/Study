package com.navistar.datadictionary.model;

import com.google.gson.annotations.SerializedName;

public class Category {
	
	@SerializedName("category")
	private String category;
	
	@SerializedName("Name")
	private String name;
	
	@SerializedName("Description")
	private String description;
	
	@SerializedName("DataType")
	private String dataType;
	
	@SerializedName("Min")
	private String min;	
	
	@SerializedName("Max")
	private String max;	

	@SerializedName("Unit")
	private String unit;	

	@SerializedName("Complexity")
	private String complexity;
	
	@SerializedName("Dimensions")
	private String dimensions;
	
	@SerializedName("DimensionsMode")
	private String dimensionsMode;
	
	@SerializedName("SampleTime")
	private String sampleTime;
	
	@SerializedName("SamplingMode")
	private String samplingMode;
	
	@SerializedName("InitialValue")
	private String initialValue;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getMin() {
		return min;
	}

	public void setMin(String min) {
		this.min = min;
	}

	public String getMax() {
		return max;
	}

	public void setMax(String max) {
		this.max = max;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getDimensions() {
		return dimensions;
	}

	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}

	public String getDimensionsMode() {
		return dimensionsMode;
	}

	public void setDimensionsMode(String dimensionsMode) {
		this.dimensionsMode = dimensionsMode;
	}

	public String getSampleTime() {
		return sampleTime;
	}

	public void setSampleTime(String sampleTime) {
		this.sampleTime = sampleTime;
	}

	public String getSamplingMode() {
		return samplingMode;
	}

	public void setSamplingMode(String samplingMode) {
		this.samplingMode = samplingMode;
	}

	public String getInitialValue() {
		return initialValue;
	}

	public void setInitialValue(String initialValue) {
		this.initialValue = initialValue;
	}

	
	
}
