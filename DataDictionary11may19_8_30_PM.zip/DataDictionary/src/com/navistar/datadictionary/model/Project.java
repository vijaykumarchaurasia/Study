package com.navistar.datadictionary.model;

public class Project {

	String path;
	int status;
	
	public Project() {
	}

	public Project(String path, int status) {
		super();
		this.path = path;
		this.status = status;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Project [path=" + path + ", status=" + status + "]";
	}
	
}
