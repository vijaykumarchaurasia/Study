package com.navistar.datadictionary.communication;

import java.util.concurrent.ExecutionException;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mathworks.engine.MatlabEngine;
import com.navistar.datadictionary.constant.JSONKeyConstant;

public class JavaMatlabIntraction {
	
	JsonElement jsonElement;	
	public JsonElement getSlddComponentsData(JsonObject jsonObject)
	{		
			
		try {
				JsonElement queryName = jsonObject.get(JSONKeyConstant.QUERY_NAME);				
				MatlabEngine matlabEngine = MatlabEngine.startMatlab();
				Object resp = matlabEngine.feval(1,queryName.getAsString(), (Object)jsonObject.get(JSONKeyConstant.COMPONENT_NAME));				
				System.out.println("Responce:"+resp);
				jsonElement = (JsonElement) resp; 			
			
		} catch (IllegalArgumentException | IllegalStateException | InterruptedException |ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return jsonElement;		
	}
	

}
