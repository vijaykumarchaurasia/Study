package com.navistar.datadictionary.communication;

import com.google.gson.JsonElement;

public interface IMatlabRequest {
	 public JsonElement loadSlddData(String projectName, String componentName); 
}
