package com.navistar.datadictionary.communication;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.navistar.datadictionary.constant.JSONKeyConstant;

public class MatlabDataRequest extends AbstractMatlabRequest{
	private JsonElement jsonElement;
	private JavaMatlabIntraction javaMatlabIntraction;

	@Override
	public JsonElement loadSlddData(String projectName, String componentName) {
		
		javaMatlabIntraction = new JavaMatlabIntraction();
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty(JSONKeyConstant.QUERY_NAME, "FetchSLDDdata_javaTesting");
		jsonObject.addProperty(JSONKeyConstant.PROJECT_NAME, projectName);
		jsonObject.addProperty(JSONKeyConstant.COMPONENT_NAME, componentName);
		jsonElement = javaMatlabIntraction.getSlddComponentsData(jsonObject);
		
		return jsonElement;
	}	
	
}
