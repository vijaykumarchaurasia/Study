package com.navistar.datadictionary.communication;

import com.google.gson.JsonElement;

public interface IMatlabResponse {
	public JsonElement getSlddResponse(); 
}
