package com.navistar.datadictionary.communication;

import com.google.gson.JsonElement;

public abstract class AbstractMatlabRequest implements IMatlabRequest{

	public JsonElement loadSlddData(String projectName, String componentName) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
