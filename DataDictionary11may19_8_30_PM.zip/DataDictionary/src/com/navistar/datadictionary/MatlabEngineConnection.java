package com.navistar.datadictionary;

import com.mathworks.engine.EngineException;
import com.mathworks.engine.MatlabEngine;

public class MatlabEngineConnection {
	public static MatlabEngine matlabEngine  = null;
	
	private MatlabEngineConnection()
	{
		
	}
	
	public static MatlabEngine getMatlabEngineInstance()
	{
		
		if(matlabEngine!=null) 
			return matlabEngine;
		else
			try {
				matlabEngine = MatlabEngine.startMatlab();
			} catch (EngineException | IllegalArgumentException | IllegalStateException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return matlabEngine;
	}

}
