package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.core.commands.operations.IOperationHistory;
import org.eclipse.core.commands.operations.IUndoContext;
import org.eclipse.core.commands.operations.IUndoableOperation;
import org.eclipse.core.commands.operations.OperationHistoryFactory;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.handlers.HandlerUtil;

import com.navistar.datadictionary.operation.ActionOperation;
import com.navistar.datadictionary.Activator;

public class UndoHandler extends AbstractHandler implements IHandler{

	//public static final String ID = "DataDictionary.undo";
	IUndoableOperation operation = null;
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		
		/*IPreferenceStore
		 * 
		 * IPreferenceStore store = Activator.getDefault().getPreferenceStore();
		
		store.putValue("minal1", "3");
		store.putValue("minal2", "5");
		store.putValue("minal3", "1");
		store.putValue("minal4", "3");
		
		store.getString("mainal3");*/
		
		//System.out.println("Calling Undo.......");
		
	    //IOperationHistory operationHistory = OperationHistoryFactory.getOperationHistory();
		IUndoableOperation operation =  new ActionOperation(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell()); 
		
		IWorkbench workbench = PlatformUI.getWorkbench();
		//IOperationHistory operationHistory = workbench.getOperationSupport().getOperationHistory();
		IOperationHistory operationHistory = OperationHistoryFactory.getOperationHistory();
	    IUndoContext undoContext = workbench.getOperationSupport().getUndoContext();
			    
	    IUndoableOperation[] undoOperationArray = operationHistory.getUndoHistory(undoContext);
	    
	    //System.out.println("undoOperationArray size : "+undoOperationArray.length);
	   
	    /*for(IUndoableOperation op:undoOperationArray)
	    {
	    	//System.out.println( " undoOperation : "+op);
	    	operation = op;
	    }*/
	    //operation = new DeltaInfoOperation(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
	    //String label = operationHistory.getUndoOperation(undoContext).getLabel();
	       
	    //System.out.println("undo operation label : "+label);
	    operation.addContext(undoContext);
	    try {
	    	//Boolean status = operation.canUndo();
	    	//System.out.println("canUndo : "+status);
			//operationHistory.execute(operation, null, null);
			//operationHistory.undo(operation, null, null);
	    	operation.undo(null, null);
	    	//operationHistory.undo(undoContext, null, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       
		/*
		// Retrieving the window
		IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindow ( event ) ;	
		// Get the history of the workbench operations
		IWorkbench workbench = window.getWorkbench ( ) ;
		IOperationHistory operationHistory = OperationHistoryFactory.getOperationHistory ( ) ;
		// Retrieving the workbench cancellation context
		IUndoContext undoContext = workbench.getOperationSupport ( ) .getUndoContext ( ) ;
		IUndoableOperation operation = new DeltaInfoOperation(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell());
		System.out.println("Called undo handler.........");
		try {
			System.out.println(operationHistory.getUndoHistory(undoContext));
			//IUndoableOperation[] undoOperationArray = operationHistory.getUndoHistory(undoContext);
			//operationHistory.execute(undoOperationArray[1], null, null);
			operation.addContext(undoContext);
			operationHistory.execute(operation, null, null);
			//IStatus status = operationHistory.undo(undoContext, null , null) ;
			//System.out.println("Undo handler execute status : "+status);
			
		} catch ( ExecutionException e ) {
			e.printStackTrace ( ) ;
		}*/

	   return null;
	}

}
