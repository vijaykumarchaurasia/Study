package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IHandler;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.action.ImportProjectAction;
import com.navistar.datadictionary.view.ProjectExplorerView;

public class ImportProjectHandler extends AbstractHandler implements IHandler{

	String path;
	static ProjectExplorerView projectExplorerView;
	Shell shell;
	
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
	
		IWorkbenchAction importProjectAction = new ImportProjectAction();
		importProjectAction.run();
		
		return null;
	}
}
