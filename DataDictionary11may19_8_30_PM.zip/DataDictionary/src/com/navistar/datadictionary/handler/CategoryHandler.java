package com.navistar.datadictionary.handler;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.handlers.HandlerUtil;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.navistar.datadictionary.categories.editor.InputEditor;
import com.navistar.datadictionary.categories.editorinput.CategoryEditorInput;
import com.navistar.datadictionary.service.JsonArrayProvider;

public class CategoryHandler extends AbstractHandler{
	
	 public static final String ID = "com.navistar.datadictionary.handler.CategoryHandler";
	 private List<CategoryEditorInput> categoryEditorInputList;
	 private JsonElement jsonElement;
	 

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		JsonArrayProvider jsonArrayProvider = new JsonArrayProvider();		
		
		 // get the page
	       IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindow(event);
	       IWorkbenchPage page = window.getActivePage();
	       // get the selection
	       ISelection selection = HandlerUtil.getCurrentSelection(event);
	       categoryEditorInputList = new CopyOnWriteArrayList<CategoryEditorInput>();	 
	 
	       // Having selected on WelcomeNoteView
	       if (selection != null && !selection.isEmpty() && selection instanceof IStructuredSelection ) {
	    	   jsonElement = (JsonArray) ((IStructuredSelection) selection).getFirstElement();
	       }	       
	    // No Selection on WelcomeNoteView
	       else {	    	  
	    	   jsonElement = jsonArrayProvider.getJsonArrayFromFile();
	       }
	       	       
	    	 for (JsonElement jsonElement : jsonElement.getAsJsonArray()) {	    	
	    		 CategoryEditorInput categoryEditorInput = new CategoryEditorInput(jsonElement);
	    		 categoryEditorInputList.add(categoryEditorInput);	    		
			}	    	 
	
	       boolean found = false;	       
	       
	       // Opening Editor references
	       IEditorReference[] eRefs = page.getEditorReferences();
	       for (IEditorReference ref : eRefs) {
	           IEditorPart editorPart = ref.getEditor(false);
	           if (editorPart != null && editorPart instanceof InputEditor) {
	               // Restore
	        	   InputEditor editor = (InputEditor) ref.getEditor(true);
	               found = true;
	 
	               boolean saved = true;
	 
	               // If editor is dirty, save it.
	               if (editor.isDirty()) {
	                   saved = page.saveEditor(editor, true);
	               }
	               if (saved) {
	  
	                   // Reset input for InputEditor.
	            	   CategoryEditorInput inputEditor = (CategoryEditorInput) editor.getEditorInput();
	            	   
	            	   Iterator<CategoryEditorInput> it = categoryEditorInputList.iterator();
	           		while (it.hasNext()) {
	           			CategoryEditorInput categoryEditorInput = (CategoryEditorInput)it.next();
	           			System.out.println("List Value:" + categoryEditorInput);
	           			if(categoryEditorInput.getName().equals(inputEditor.getName()))
						{
							categoryEditorInputList.remove(categoryEditorInput);
						}
	           		}
	            	   
	            	   try {
						page.reuseEditor(editor, inputEditor);
						   editor.showData();
					} catch (Exception e) {
						e.printStackTrace();
					}
	            	   
	               }
	           }
	       }	           
	      
	       if (!found) {
	           if(categoryEditorInputList.size()>0)
			   {
				   Iterator<CategoryEditorInput> it = categoryEditorInputList.iterator();
			   		while (it.hasNext()) {
			   			CategoryEditorInput categoryEditorInput = it.next();
			   		
					try {
						page.openEditor(categoryEditorInput, InputEditor.ID);
					} catch (PartInitException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			   		}
					
				}
	 
	       }
	       else
	       {
	    	   if(categoryEditorInputList.size()>0)
		       {
	    		   Iterator<CategoryEditorInput> it = categoryEditorInputList.iterator();
	           		while (it.hasNext()) {
	           			CategoryEditorInput categoryEditorInput = it.next();
	           		
					try {
						page.openEditor(categoryEditorInput, InputEditor.ID);
					} catch (PartInitException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	           		}
					
				}
		    	   
		       } 
		
		return null;		
	}	

}
