package com.navistar.datadictionary.stringutils;

public class StringUtility {

	public String[] getSplittedStringArray(String givenString,String delimeter)
	{
		String splitStringArray[] = givenString.split(delimeter);
		return splitStringArray;	
	}
}
