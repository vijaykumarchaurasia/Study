package com.navistar.datadictionary.categories.editorinput;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

public class WelcomeNoteEditorInput implements IEditorInput{

	private String text = "Welcome Note";
	
	public WelcomeNoteEditorInput() {
	}
	
	@Override
	public Object getAdapter(Class arg0) {
		return text;
	}

	@Override
	public boolean exists() {
		return false;
	}

	@Override
	public ImageDescriptor getImageDescriptor() {
		return null;
	}

	@Override
	public String getName() {
		return text;
	}

	@Override
	public IPersistableElement getPersistable() {
		return null;
	}

	@Override
	public String getToolTipText() {
		return text;
	}

}
