package com.navistar.datadictionary.categories.editorinput;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.navistar.datadictionary.constant.JSONKeyConstant;

public class CategoryEditorInput implements IEditorInput{		
	private JsonElement jsonElement;
	public CategoryEditorInput(JsonElement jsonElement) {		
		this.jsonElement = jsonElement;
	}	

	private String getCategoryName()
	{		
		JsonObject jsonObject = jsonElement.getAsJsonArray().get(0).getAsJsonObject();
		JsonElement jsonElement =  jsonObject.get(JSONKeyConstant.CATEGORY);		
		 return jsonElement.getAsString();		
	}	
	
	public JsonElement getCategoryAsJSONElement()
	{
		return jsonElement;		
	}

	@Override
	public boolean exists() {
		return false;
	}

	@Override
	public ImageDescriptor getImageDescriptor() {
		return null;
	}

	@Override
	public String getName() {	
		return getCategoryName();
		
	}	

	@Override
	public IPersistableElement getPersistable() {
		return null;
	}

	@Override
	public String getToolTipText() {
		return getCategoryName();
	}

	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}

}
