package com.navistar.datadictionary.categories.editor;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;

import com.navistar.datadictionary.editor.AbstractBaseEditor;

public class OutputEditor extends AbstractBaseEditor {

	public OutputEditor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void showData() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void createPartControl2(Composite parent) {
		// TODO Auto-generated method stub
		Composite container = new Composite(parent, SWT.NONE);
	    container.setLayout(new GridLayout(2, false));

	    Label lblOutput = new Label(container, SWT.NONE);
	    lblOutput.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
	            false, 1, 1));
	    lblOutput.setText("Output");

	}

	@Override
	protected Control[] registryDirtyControls() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
		// TODO Auto-generated method stub

	}

	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
