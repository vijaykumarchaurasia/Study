package com.navistar.datadictionary.categories.editor;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;

import com.navistar.datadictionary.constant.DataDictionaryConstant;
import com.navistar.datadictionary.editor.AbstractBaseEditor;

public class WelcomeNoteEditor extends AbstractBaseEditor {
	public WelcomeNoteEditor() {
	}
	public static final String ID = "com.navistar.datadictionary.categories.editor.WelcomeNoteEditor";
	private Label label_welcomeNoteText;

	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void showData() {
		label_welcomeNoteText.setText(DataDictionaryConstant.WELCOME_NOTE_TEXT);
		
	}

	@Override
	protected void createPartControl2(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
	    container.setLayout(new GridLayout(1, false));
	 
	    label_welcomeNoteText = new Label(container, SWT.NONE);
	    label_welcomeNoteText.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, true,
	               true, 1, 1));
	    
	}

	@Override
	protected Control[] registryDirtyControls() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
		// TODO Auto-generated method stub
		
	}
	
}
