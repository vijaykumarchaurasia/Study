package com.navistar.datadictionary.categories.editor;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.command.AbstractRowCommand;
import org.eclipse.nebula.widgets.nattable.command.ILayerCommand;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.AbstractUiBindingConfiguration;
import org.eclipse.nebula.widgets.nattable.config.DefaultNatTableStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IEditableRule;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.ui.binding.UiBindingRegistry;
import org.eclipse.nebula.widgets.nattable.ui.menu.MenuItemProviders;
import org.eclipse.nebula.widgets.nattable.ui.menu.PopupMenuBuilder;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IReusableEditor;
import org.eclipse.ui.IWorkbenchPartConstants;

import com.google.gson.JsonArray;
import com.google.gson.JsonPrimitive;
import com.navistar.datadictionary.categories.editorinput.CategoryEditorInput;
import com.navistar.datadictionary.constant.DataDictionaryConstant;
import com.navistar.datadictionary.editor.AbstractBaseEditor;
import com.navistar.datadictionary.service.JsonDataProvider;
import com.navistar.datadictionary.service.NatTableDisplayServise;
import com.navistar.datadictionary.service.NatTableService;

public class InputEditor extends AbstractBaseEditor implements IReusableEditor{
	public static final String ID = "com.navistar.datadictionary.categories.editor.InputEditor";
	private NatTable natTable;	

	public InputEditor() {
	}

	@Override
	public void showData() {
		
		CategoryEditorInput inputEditor = (CategoryEditorInput) this.getEditorInput();
		   // Displaying tab name
		this.setPartName(inputEditor.getName() == null ? "" : inputEditor.getName());		
	}	
	

	@Override
	protected void createPartControl2(Composite parent) {
		
		CategoryEditorInput inputEditor = (CategoryEditorInput) this.getEditorInput();
		parent.setLayout(new GridLayout(2,false));
		Button btnAddDataObj = new Button(parent, SWT.PUSH);
		btnAddDataObj.setBounds(10, 20, 75, 25);
		btnAddDataObj.setText(DataDictionaryConstant.BTN_ADDDATAOBJECT);
		btnAddDataObj.addSelectionListener(new SelectionListener() {
		      public void widgetDefaultSelected(SelectionEvent e) {
		      }

		      public void widgetSelected(SelectionEvent e) {
		    	  int rowPosition = MenuItemProviders.getNatEventData(e).getRowPosition();
		    	  natTable.doCommand(new InsertRowCommand<>(natTable, rowPosition, inputEditor.getCategoryAsJSONElement()));
		      }  
		      
		    });/*.addSelectionListener(new SelectionAdapter() {
			@Override
            public void widgetSelected(SelectionEvent event) {
				int rowPosition = btnAddDataObj
			}
		});*/
		Button btnNewButton = new Button(parent, SWT.PUSH);
		btnNewButton.setBounds(10, 20, 75, 25);
		btnNewButton.setText(DataDictionaryConstant.BTN_FINDINMODEL);		
		
		
		natTable = new NatTableDisplayServise().displayNatTable(parent,inputEditor.getCategoryAsJSONElement());
		natTable.addConfiguration(new DefaultNatTableStyleConfiguration()); 
        
        natTable.addConfiguration(new AbstractRegistryConfiguration() { 

            @Override 
            public void configureRegistry(IConfigRegistry configRegistry) { 
               configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE, 
                         IEditableRule.ALWAYS_EDITABLE); 
                 
            } 

          });
		
		natTable.configure();
		GridDataFactory.fillDefaults().grab(true, true).applyTo(natTable);	 		
		   
	}
	
	/**
     * Command to insert a row.
     */
    class InsertRowCommand<T> extends AbstractRowCommand {

        private final T object;

        public InsertRowCommand(ILayer layer, int rowPosition, T object) {
            super(layer, rowPosition);
            this.object = object;
        }

        protected InsertRowCommand(InsertRowCommand<T> command) {
            super(command);
            this.object = command.object;
        }

        @Override
        public ILayerCommand cloneCommand() {
            return new InsertRowCommand<>(this);
        }

        public T getObject() {
            return this.object;
        }

    }
	@Override
	public void setInput(IEditorInput input) {
       super.setInput(input);
       firePropertyChange(IWorkbenchPartConstants.PROP_INPUT);
	}
	

	@Override
	protected Control[] registryDirtyControls() {
		return null;
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
	}

	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}
	
	@Override
	protected void setPartName(String partName) {
		// TODO Auto-generated method stub
		super.setPartName(partName);
	}
	
	@Override
	protected void setTitleToolTip(String toolTip) {
		// TODO Auto-generated method stub
		super.setTitleToolTip(toolTip);
	}
	
	@Override
	protected void setContentDescription(String description) {
		// TODO Auto-generated method stub
		super.setContentDescription(description);
	}
	
	
   
   @Override
public void dispose() {
	// TODO Auto-generated method stub
	super.dispose();
	   
}

@Override
public void setPartProperty(String key, String value) {
	// TODO Auto-generated method stub
	super.setPartProperty(key, value);
}
	
}
