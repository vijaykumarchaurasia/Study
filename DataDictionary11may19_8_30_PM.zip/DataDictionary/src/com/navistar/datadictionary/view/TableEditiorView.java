package com.navistar.datadictionary.view;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.ApplicationActionBarAdvisor;

public class TableEditiorView extends ViewPart{
	public static final String ID = "com.navistar.datadictionary.view.TableEditiorView";
	private Composite composite;
	private SashForm sashForm;
	private CTabFolder cTabFolder;

	 public TableEditiorView() {
		// TODO Auto-generated constructor stub

		
	}
	

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		 Composite container = new Composite(parent, SWT.NONE);
		    container.setLayout(new GridLayout(4, false));

		    Label lblDeptNo = new Label(container, SWT.NONE);
		    lblDeptNo.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
		            false, 1, 1));
		    Composite composite = new Composite(container, SWT.NONE);
		    
		    Label lblNewLabel = new Label(composite, SWT.NONE);
		    lblNewLabel.setBounds(28, 21, 245, 17);
		    lblNewLabel.setText("Table Editor");
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void dispose() {
		ApplicationActionBarAdvisor.getInstance().tableEditorAction.setChecked(false);
	}

	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}