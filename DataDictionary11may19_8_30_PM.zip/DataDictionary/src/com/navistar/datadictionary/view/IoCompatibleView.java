package com.navistar.datadictionary.view;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.ApplicationActionBarAdvisor;

public class IoCompatibleView extends ViewPart// implements IPropertyListener 
{
	public static final String ID = "com.navistar.datadictionary.view.IoCompatibleView";
	
	private Composite composite;
	private SashForm sashForm;
	private CTabFolder cTabFolder;

	public IoCompatibleView() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		
		
		 Composite container = new Composite(parent, SWT.NONE);
		    container.setLayout(new GridLayout(2, false));

		    Label lblDeptNo = new Label(container, SWT.NONE);
		    lblDeptNo.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
		            false, 1, 1));
		   // lblDeptNo.setText("Activity Log View");
		

	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub

	}
	
	@Override
	public void dispose() {
		ApplicationActionBarAdvisor.getInstance().ioCopatibilityAction.setChecked(false);
	}

	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
