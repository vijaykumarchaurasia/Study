package com.navistar.datadictionary.view;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.ViewPart;

import com.navistar.datadictionary.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.action.ActivityLogAction;

public class ActivityLogView extends ViewPart{
	
	public static final String ID = "com.navistar.datadictionary.view.ActivityLogView";	
	
	public interface ActionCallListener
	{
		public void displayViewCheck(boolean flag);
	}
	
	public ActivityLogView() {
		
	}
	
	@Override
	public void createPartControl(Composite parent) {		
		 Composite container = new Composite(parent, SWT.NONE);
	    container.setLayout(new GridLayout(3, false));

	    Label lblDeptNo = new Label(container, SWT.NONE);
	    lblDeptNo.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
	            false, 1, 1));
	    new Label(container, SWT.NONE);
	    
	    Composite composite = new Composite(container, SWT.NONE);
	    
	    Label lblNewLabel = new Label(composite, SWT.NONE);
	    lblNewLabel.setBounds(28, 21, 245, 17);
	    lblNewLabel.setText("Activity Log");
		
	}

	@Override
	public void setFocus() {
		
	}
	
	@Override
	public void dispose() {		
		ApplicationActionBarAdvisor.getInstance().activityLogAction.setChecked(false);		
	}

	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}
}
