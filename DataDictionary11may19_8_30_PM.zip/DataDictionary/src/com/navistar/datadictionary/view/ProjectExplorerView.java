package com.navistar.datadictionary.view;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Vector;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Path;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.part.ViewPart;
import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

import com.navistar.datadictionary.ApplicationActionBarAdvisor;
import com.navistar.datadictionary.action.ContextMenuActions;
import com.navistar.datadictionary.action.ImportProjectAction;
import com.navistar.datadictionary.constant.DataDictionaryConstant;
import com.navistar.datadictionary.model.Project;
import com.navistar.datadictionary.other.Node;
import com.navistar.datadictionary.other.NodeComparator;
import com.navistar.datadictionary.provider.CustomLabelProvider;
import com.navistar.datadictionary.provider.TreeContentProvider;
import com.navistar.datadictionary.service.ContextMenuService;
import com.navistar.datadictionary.service.ImportProjectStructureService;

public class ProjectExplorerView extends ViewPart implements ImportProjectAction.DirectoryFile{
	
	private ImportProjectAction importProjectAction = new ImportProjectAction();
	public static final String ID = "com.navistar.datadictionary.view.ProjectExplorerView";
	private TreeViewer viewer;
	static Shell shell = new Shell();
	static final Tree tree = new Tree(shell, SWT.BORDER);
	public static Vector<Node> nodes = new Vector<Node>();
	//current imported project component
	List<String> currentImportedcomponentList = new ArrayList<>();		
	String parentElement;
	public static LinkedHashMap<String, Project> projectAndStatusMap = new LinkedHashMap<>();
	ContextMenuActions openProjectAction = new ContextMenuActions();
	ContextMenuActions closeProjectAction = new ContextMenuActions();
	ContextMenuActions removeProjectAction = new ContextMenuActions();

	ContextMenuActions openComponentAction = new ContextMenuActions();
	ContextMenuActions resolveInconsistencyAction = new ContextMenuActions();
	ContextMenuActions checkComponentInputAction = new ContextMenuActions();
	ContextMenuService contextMenuService = new ContextMenuService();

	Boolean checkOpenProjectStatus = true;
	Boolean checkCloseProjectStatus = false;
	Boolean checkRemoveProjectStatus = true;
	public ProjectExplorerView() {}	
		
	@Override
	public void createPartControl(Composite parent) {	
		 
		viewer = new TreeViewer(parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
		viewer.setContentProvider(new TreeContentProvider());
		viewer.setLabelProvider(new CustomLabelProvider());   
		importProjectAction.SetViewer(this);
		
		//Display imported projects in gray
		Device device = parent.getDisplay();
		Color color=new Color(device, 105, 105, 105);
		viewer.getControl().setForeground(color); 
	     
        
      MenuManager contextMenu = new MenuManager("#ViewerMenu"); //$NON-NLS-1$
      contextMenu.setRemoveAllWhenShown(true);
	  viewer.addDoubleClickListener(new IDoubleClickListener() {

			@Override
			public void doubleClick(DoubleClickEvent event) {
				ImportProjectStructureService importService = new ImportProjectStructureService();
				boolean dialogReturnValue = false;
				String firstProjectOpen = DataDictionaryConstant.EMPTY_STRING;;
				//add popup if any project is open
				for(String projectPath : ProjectExplorerView.projectAndStatusMap.keySet())
				{
					if(ProjectExplorerView.projectAndStatusMap.get(projectPath).getStatus()==1)
					{
						dialogReturnValue = MessageDialog.openConfirm(shell, "Warning", DataDictionaryConstant.OPEN_PROJECT_MESSAGE);
						firstProjectOpen = DataDictionaryConstant.EMPTY_STRING;;
						break;
					}
					firstProjectOpen = DataDictionaryConstant.PROJECT_OPEN_FIRST_TIME;
				}
				
				if((dialogReturnValue) || (DataDictionaryConstant.PROJECT_OPEN_FIRST_TIME.equals(firstProjectOpen)))
				{
					String projectName = contextMenuService.enableProject(viewer);				
					Tree tree = viewer.getTree();
					int treeItemCount = tree.getItems().length;
					for(int i=0;i<treeItemCount;i++)
					{
						if(projectName.equals(tree.getItem(i).getText()))
							importService.updateProjectStatus(projectName, DataDictionaryConstant.OPEN_PROJECT_STATUS);
						else
							importService.updateProjectStatus(tree.getItem(i).getText(), DataDictionaryConstant.CLOSE_PROJECT_STATUS);
					}
				}				
			}
		});	
      contextMenu.addMenuListener(new IMenuListener() {
          @Override
          public void menuAboutToShow(IMenuManager mgr) {
			try {
					fillContextMenu(mgr);
				} catch (Exception e) {

				}
			}     
		 });

      Menu menu = contextMenu.createContextMenu(viewer.getControl());
      viewer.getControl().setMenu(menu);      
	}
	
	public static void traditional() {
	    for (int i = 0; nodes != null && i < nodes.size(); i++) {
	      Node node = (Node) nodes.elementAt(i);
	      addNode(null, node);
	    }
	  }
	  private static void addNode(TreeItem parentItem, Node node) {
	    TreeItem item = null;
	    if (parentItem == null)
	      item = new TreeItem(tree, SWT.NONE);
	    else
	      item = new TreeItem(parentItem, SWT.NONE);
	    item.setText(node.getName());
	    Vector subs = node.getSubCategories();
	    for (int i = 0; subs != null && i < subs.size(); i++)
	      addNode(item, (Node) subs.elementAt(i));
	  }
	
	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/*
	 * Function for Pop-up Menu 
	 * */	
	protected void fillContextMenu(IMenuManager contextMenu) {
		IStructuredSelection thisSelection = (IStructuredSelection) viewer.getSelection();
		ImportProjectStructureService importUtilService = new ImportProjectStructureService();
		Node selectedNode = (Node) thisSelection.getFirstElement();
		if (null == selectedNode.getParent()) {

			contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
			openProjectAction = new ContextMenuActions(DataDictionaryConstant.OPEN_PROJECT, viewer);
			contextMenu.add(openProjectAction);
			closeProjectAction = new ContextMenuActions(DataDictionaryConstant.CLOSE_PROJECT, viewer);
			contextMenu.add(closeProjectAction);
			closeProjectAction.setEnabled(false);

			removeProjectAction = new ContextMenuActions(DataDictionaryConstant.REMOVE_PROJECT, viewer);
			contextMenu.add(removeProjectAction);

			if ((importUtilService.getProjectStatus(selectedNode.getName())) == 1) {
				openProjectAction.setEnabled(false);
				closeProjectAction.setEnabled(true);
				// checkCloseProjectStatus = true;
			} else {
				openProjectAction.setEnabled(true);
				closeProjectAction.setEnabled(false);
			}

		} else {
			contextMenu.add(new GroupMarker(IWorkbenchActionConstants.MB_ADDITIONS));
			openComponentAction = new ContextMenuActions(DataDictionaryConstant.OPEN_COMPONENT, viewer);
			contextMenu.add(openComponentAction);
			resolveInconsistencyAction = new ContextMenuActions(DataDictionaryConstant.RESOLVE_INCONSISTENCY, viewer);
			contextMenu.add(resolveInconsistencyAction);
			checkComponentInputAction = new ContextMenuActions(DataDictionaryConstant.CHECK_COMPONENT_INPUTS, viewer);
			contextMenu.add(checkComponentInputAction);
		}

	} 
    
	/**
	 * Function used to get a project with component list and set it to TreeViewer
	 */
	@Override
	public TreeViewer importProject(String filePath,int importStatus) {	
		ImportProjectStructureService importUtilService = new ImportProjectStructureService();
		File parentFileObject = new File(filePath);
		parentElement = parentFileObject.getName();
		
		Node category = importUtilService.createTreeStructure(filePath, importStatus);
		nodes.add(category);
		
	    //maintain every project status
	    projectAndStatusMap = importUtilService.setProjectandStaus(projectAndStatusMap, parentFileObject.getPath(), importStatus);
	    Collections.sort(nodes,new NodeComparator());
	    
	    viewer.setInput(nodes);	
	    maintainProjectStatus();
	    return viewer;
	}
		
	 private ImageDescriptor createImageDescriptor() {
	        Bundle bundle = FrameworkUtil.getBundle(CustomLabelProvider.class);
	        URL url = FileLocator.find(bundle, new Path("icons/search.png"), null);
	        return ImageDescriptor.createFromURL(url);
	    }

		@Override
		public void dispose() {
			ApplicationActionBarAdvisor.getInstance().projectExplorerAction.setChecked(false);
		}
		
	private void maintainProjectStatus()
	{
		TreeItem itemList[] = viewer.getTree().getItems();
		for(String projectPath : projectAndStatusMap.keySet())
		{
			if(projectAndStatusMap.get(projectPath).getStatus()==0)
			{
				String folder[] = projectPath.split("\\\\");
				String projectName = folder[folder.length-1];

				for(TreeItem treeItem1 : itemList)
				{
					if(projectName.equals(treeItem1.getText()))
					{
						treeItem1.setItemCount(DataDictionaryConstant.CLOSE_PROJECT_TREEITEM_COUNT);
					}
				}
			}
		}
	}
}
