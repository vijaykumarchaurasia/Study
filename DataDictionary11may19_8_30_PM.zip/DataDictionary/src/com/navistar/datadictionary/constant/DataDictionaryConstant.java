package com.navistar.datadictionary.constant;

public interface DataDictionaryConstant {
	
	String CATEGORY_INPUT = "Input";
	String BTN_ADDDATAOBJECT = "Add Data Object";
	String BTN_FINDINMODEL = "Find in Model";
	int MAXSTACKSIZE = 5;
	String IMPORT_PROJECT = "Import Project";
	String WELCOME_NOTE_TEXT = "Welcome To Data Dictionary";
	String OPEN_PROJECT = "Open Project";
	String CLOSE_PROJECT = "Close Project";
	String REMOVE_PROJECT = "Remove Project";
	String OPEN_COMPONENT = "Open Component";
	String RESOLVE_INCONSISTENCY = "Resolve Inconsistency";
	String CHECK_COMPONENT_INPUTS = "Check Component's Inputs";
	String INVALID = "Invalid";
	String IMPORT_PROJECT_EXCEPTION = "Please select valid project";
	String PROJECT_OPEN_FIRST_TIME = "firstProjectOpen";
	String OPEN_PROJECT_MESSAGE = "Are you sure, you want to open a new project";
	String EMPTY_STRING = "";
	int OPEN_PROJECT_STATUS = 1;
	int CLOSE_PROJECT_STATUS = 0;
	int CLOSE_PROJECT_TREEITEM_COUNT = 0;
			
/* *************icons path************** */
	

}
