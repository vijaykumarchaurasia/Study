package com.navistar.datadictionary.constant;

public interface JSONKeyConstant {
	String QUERY_NAME = "queryName";
	String PROJECT_NAME = "projectName";
	String COMPONENT_NAME = "componentName";
	String CATEGORY = "category";	

}
