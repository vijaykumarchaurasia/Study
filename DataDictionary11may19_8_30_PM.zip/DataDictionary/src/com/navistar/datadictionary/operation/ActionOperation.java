package com.navistar.datadictionary.operation;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.operations.AbstractOperation;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.PlatformUI;

import com.navistar.datadictionary.editor.DeptEditor;
import com.navistar.datadictionary.model.TableCell;

public class ActionOperation extends AbstractOperation{
 
    private Shell shell;
     
    public ActionOperation(Shell shell) {
        super("Test operation");
        this.shell = shell;
    }
 
    @Override
    public IStatus execute(IProgressMonitor monitor, IAdaptable info)
            throws ExecutionException {
        MessageDialog.openInformation(shell, "Test", "Action execute");
        return Status.OK_STATUS;
    }
 
    @Override
    public IStatus redo(IProgressMonitor monitor, IAdaptable info)
            throws ExecutionException {
        MessageDialog.openInformation(shell, "Test", "action Redo execute");
        return Status.OK_STATUS;
    }
 
    @Override
    public IStatus undo(IProgressMonitor monitor, IAdaptable info)
            throws ExecutionException {
    	
        Object data = null;
        TableCell key = null;
        System.out.println("Stack size : "+DeptEditor.cellStackForUndo.size());
        for ( Map.Entry<TableCell, Object> entry : DeptEditor.cellStackForUndo.entrySet()) {
            key = entry.getKey();
            data = entry.getValue();
            
            System.out.println("key : "+key+"    ,value : "+data);
        }
        
        if(DeptEditor.cellStackForUndo.isEmpty() || (data == null))
        {
        	MessageDialog.openInformation(shell, "Undo", "No operation available for undo");
        	
        	if(DeptEditor.cellStackForUndo.isEmpty())
        	{
        		DeptEditor.cellStackForUndo = new LinkedHashMap<>();
        		System.out.println("Edit count : "+DeptEditor.editCount);
        		DeptEditor.editCount = 1;
        		System.out.println("After clearing stackSize : "+DeptEditor.cellStackForUndo.size());
        	}
        }
        else
        {
        	int row = key.getRowIndex();
        	int column = key.getColumnIndex();
        	
        	System.out.println("Data pop from stack : "+data+"   Cell : "+(column-1)+" , "+(row-1));
        	
        	System.out.println("New value : "+DeptEditor.bodyDataProvider.getDataValue(column-1, row-1).toString());
        	
        	DeptEditor.bodyDataProvider.setDataValue(column-1, row-1, data);
            DeptEditor.natTable.refresh();
            
        	DeptEditor.cellStackForUndo.remove(key);
        }
        
        return Status.OK_STATUS;
    }
    
    @Override
    public boolean canUndo() {
    	return super.canUndo();
    }
}
