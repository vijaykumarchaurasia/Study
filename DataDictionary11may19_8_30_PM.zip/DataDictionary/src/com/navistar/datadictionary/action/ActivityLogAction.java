package com.navistar.datadictionary.action;

import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

public class ActivityLogAction extends AbstractAction implements IWorkbenchAction{

	private static final String ID = "com.navistar.datadictionary.ActivityLogAction";
	public ActivityLogAction() {
		setId(ID);
	}
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
