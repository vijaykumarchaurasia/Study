package com.navistar.datadictionary.action;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.TreeViewer;

import com.navistar.datadictionary.service.ContextMenuService;

public class ContextMenuActions extends Action {

	public ContextMenuActions() {
		
	}
	private String actionName;
	private TreeViewer viewer;
	public ContextMenuActions(String actionName, TreeViewer viewer) {
		super(actionName);
		this.actionName = actionName;		
		this.viewer = viewer;		
	}
	
	/**
	 * this method is used to handle the actions on clicking the option of context menu
	 * 
	 */
	public void run() {
		ContextMenuService contextMenuService = new ContextMenuService();
		contextMenuService.performContextMenuAction(actionName, viewer);
	};
	
	@Override
	public void setEnabled(boolean enabled) {
		super.setEnabled(enabled);
	}
	
}
