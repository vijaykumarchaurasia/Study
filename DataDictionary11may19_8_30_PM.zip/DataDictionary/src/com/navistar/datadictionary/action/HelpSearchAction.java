package com.navistar.datadictionary.action;

import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

public class HelpSearchAction extends AbstractAction implements IWorkbenchAction{

	private static final String ID = "com.navistar.datadictionary.HelpSearchAction";
	public HelpSearchAction() {
		setId(ID);
	}
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
