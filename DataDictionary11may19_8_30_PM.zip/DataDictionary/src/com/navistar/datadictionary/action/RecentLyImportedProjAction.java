package com.navistar.datadictionary.action;

import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

public class RecentLyImportedProjAction extends AbstractAction implements IWorkbenchAction{

	private static final String ID = "com.navistar.datadictionary.RecentLyImportedProjAction";
	public RecentLyImportedProjAction() {
		setId(ID);
	}
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
