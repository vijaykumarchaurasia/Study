package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;

import com.navistar.datadictionary.constant.DataDictionaryConstant;
import com.navistar.datadictionary.service.DirectoryDialogService;
import com.navistar.datadictionary.view.ProjectExplorerView;

public class ImportProjectAction extends Action implements IWorkbenchAction {	
	private Shell shell;
	private String path;
	static ProjectExplorerView projectExplorerView ;
	private static final String ID = "com.navistar.datadictionary.action.ImportProjectAction";
		
	public ImportProjectAction()
	{
		setId(ID);
		shell = new Shell();		
	}
	
	public ImportProjectAction(ProjectExplorerView projectExplorerView)
	{			
		this.projectExplorerView = projectExplorerView;
	}

	@Override
	public void run() {
		DirectoryDialogService directoryDialog = new DirectoryDialogService();
    	path = directoryDialog.openDirectoryDialog(shell);
    	int importProjectStatus = 0;
    	
    	//This is used to check valid path is choosen or not
    	if(DataDictionaryConstant.INVALID.equals(path))
    	{
    		MessageDialog.openWarning(shell, "Warning", DataDictionaryConstant.IMPORT_PROJECT_EXCEPTION);
    	}
    	else if(path != null)
    	{
    		projectExplorerView.importProject(path,importProjectStatus);
    	}
	  }
	
	/*
	 * Interface created for callback
	 */
	public interface DirectoryFile  {

		public TreeViewer importProject( String filepath,int status);
	
	}
	
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}
	
	public void SetViewer(ProjectExplorerView projectExplorerView)
	{
		this.projectExplorerView = projectExplorerView;
	}

}