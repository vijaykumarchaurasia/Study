package com.navistar.datadictionary.action;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.util.IPropertyChangeListener;

public abstract class AbstractAction extends Action{
	private String viewId;
	
	/*public AbstractAction()
	{
		
	}*/
	
	public void setViewId(String viewId)
	{
		this.viewId = viewId;		
	}
	
	public String getViewId()
	{
		return viewId;
		
	}

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return super.getId();
	}

	@Override
	public String getText() {
		// TODO Auto-generated method stub
		return super.getText();
	}

	@Override
	public String getToolTipText() {
		// TODO Auto-generated method stub
		return super.getToolTipText();
	}

	@Override
	public boolean isChecked() {
		// TODO Auto-generated method stub
		return super.isChecked();
	}

	@Override
	public void setChecked(boolean checked) {
		// TODO Auto-generated method stub
		super.setChecked(checked);
	}

	@Override
	public void setEnabled(boolean enabled) {
		// TODO Auto-generated method stub
		super.setEnabled(enabled);
	}

	@Override
	public void setId(String id) {
		// TODO Auto-generated method stub
		super.setId(id);
	}

	@Override
	public void setImageDescriptor(ImageDescriptor newImage) {
		// TODO Auto-generated method stub
		super.setImageDescriptor(newImage);
	}

	@Override
	public void setText(String text) {
		// TODO Auto-generated method stub
		super.setText(text);
	}

	@Override
	public void setToolTipText(String toolTipText) {
		// TODO Auto-generated method stub
		super.setToolTipText(toolTipText);
	}

	@Override
	public void addPropertyChangeListener(IPropertyChangeListener listener) {
		// TODO Auto-generated method stub
		super.addPropertyChangeListener(listener);
	}

	@Override
	public void removePropertyChangeListener(IPropertyChangeListener listener) {
		// TODO Auto-generated method stub
		super.removePropertyChangeListener(listener);
	}

}
