package com.navistar.datadictionary.util;

import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.commons.io.filefilter.WildcardFileFilter;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

public class FileUtility {
	
	static public Map<String, String> slddPathMap = new LinkedHashMap<>();
	
	/**
	 * Function will retrieve list of components i.e. sldd files in folder
	 * @param dirPath
	 * @return
	 */
	public List<String> getComponentList(String dirPath)
	{
		List<String> componentNameList = new ArrayList<>();		
		File topDir = new File(dirPath);
		List<File> directories = new ArrayList<>();
		List<File> textFiles = new ArrayList<>();
		directories.add(topDir);

		List<String> filterWildcards = new ArrayList<>();
		filterWildcards.add("*.sldd");
		FileFilter typeFilter = new WildcardFileFilter(filterWildcards);

		while (directories.isEmpty() == false)
		{
			List<File> subDirectories = new ArrayList<File>();
			for(File f : directories)
			{
				subDirectories.addAll(Arrays.asList(f.listFiles((FileFilter)DirectoryFileFilter.INSTANCE)));			
				textFiles.addAll(Arrays.asList(f.listFiles(typeFilter)));
			}
			directories.clear();
			directories.addAll(subDirectories);		
		}
		
		for(File fileName : textFiles)
		{
			slddPathMap.put(fileName.getPath(), FilenameUtils.getBaseName(fileName.getName()));
			componentNameList.add(FilenameUtils.getBaseName(fileName.getName()));
		}
		return componentNameList;		
	}
	
	public boolean writeIntoJsonFile(String data, String fileName)
	{
		FileWriter fileWriter;
		try {
			fileWriter = new FileWriter(fileName);
			fileWriter.write(data);
			fileWriter.flush();
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			return false;
		} catch (IOException e) {
			//e.printStackTrace();
			return false;
		}	
		return true;
	}
	
	public JsonElement readFromJsonFile(String fileName)
	{
		JsonParser parser = new JsonParser();
		JsonElement jsonElement = null;
		FileReader fileReader;
		try {
			fileReader = new FileReader(fileName);
			jsonElement = (JsonElement)parser.parse(fileReader);
		} catch (FileNotFoundException e) {
			//e.printStackTrace();
			return null;
		}
		return jsonElement;
	}
}
