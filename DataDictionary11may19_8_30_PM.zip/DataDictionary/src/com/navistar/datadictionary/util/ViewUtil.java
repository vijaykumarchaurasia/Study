package com.navistar.datadictionary.util;

import org.eclipse.ui.IViewReference;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;

public class ViewUtil {
	
	public static void showHideView(String viewId,boolean status)
	{		
		
		try 
		{
			if (status)
			{
				PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().showView(viewId);
			}
			else
			{
				IViewReference[] views = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getViewReferences();
				for (IViewReference iViewReference : views) {
					 if ( iViewReference.getId().equals(viewId) ) 
					 {
						 	iViewReference.getPage().hideView(iViewReference);
							break;
					}
				}
				
			}
			
		} catch (PartInitException e1) {
			e1.printStackTrace();
		} 
	}

}
