
%command to run function
%[timeTorunFunction] = CalculateFunctionTime(FetchSLDDdata_javaTesting('aeafm.sldd'))
function [timeTorunFunction] = CalculateFunctionTime(function_name)
function_name = @()FetchSLDDdata_javaTesting('aeafm.sldd')
timeTorunFunction = timeit(function_name,1)