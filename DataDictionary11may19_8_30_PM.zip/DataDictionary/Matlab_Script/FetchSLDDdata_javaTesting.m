
%command
%[data1] = FetchSLDDdata_javaTesting(SLDD_Name)


function [data1] = FetchSLDDdata_javaTesting(SLDD_Name)
siz_new = 0;
myDictionaryObj = Simulink.data.dictionary.open(SLDD_Name);
num_Of_Entries=myDictionaryObj.NumberOfEntries;
dDataSectObj = getSection(myDictionaryObj,'Design Data');
allEntries = find(dDataSectObj);

if num_Of_Entries == 0
    errordlg('SLDD File Does Not Contain Data','Data Error');
end
for k=1:num_Of_Entries
 property_name=allEntries(k).Name;  %get all data object's name
 a=getValue(allEntries(k));      
 attributes{k}=a;                   %store attributes
 dataObjectCategories{k}=a.objectType;        %store categories
 dataObject_Name{k}=property_name;
 
end   
categories = unique(dataObjectCategories);    %store categories
inc = 1;
i=1;
lcl_cntr=1;
while(i<(length(categories)+1))    
    for k=1:num_Of_Entries
        if strcmp((attributes{k}.objectType),(categories{i}))
            b{inc}=attributes{k};
            inc= inc+1;           
        end
        a=getValue(allEntries(k));
%         fields = fieldnames(a);
        if strmatch(a.objectType,categories{i},'exact') 
            dataObject_Name1{lcl_cntr}=allEntries(k).Name;
            fields = fieldnames(a);
            lcl_cntr = lcl_cntr +1;
        end
    end
    inc_v = 1;
%     assignin('base',strcat('store_',categories{i}),b);
%     assignin('base',strcat('name_',categories{i}),dataObject_Name1);
    store_categories(inc_v,:) = b;
    name_categories(inc_v,:) =dataObject_Name1;
   for attri = 1:length(store_categories)
        store_attribute =store_categories(inc_v,:);
        name_of_attribute = name_categories(inc_v,:);
        Name(attri,1)=string(name_of_attribute(attri));
        if nnz(double(ismember(fields,'Value'))')
            try
                Valu(attri,:)=store_attribute{attri}.Value;
            catch
                if strmatch(categories{i},'Map','exact')
                    first_attr_Val_siz = size(store_attribute{1}.Value);
                    size_data = size(store_attribute{attri}.Value);
                    if size_data(1) < first_attr_Val_siz(1)
                        Valu2(1:first_attr_Val_siz(1),:) = [store_attribute{attri}.Value ; zeros(first_attr_Val_siz(1), (first_attr_Val_siz(1)-size_data(1)))'] ;
                        Valu(attri,:) = Valu2(1,:);
                    else 
                        Valu2(1:size_data(1),:) = store_attribute{attri}.Value ;
                        Valu(attri,:) = Valu2(1,:);
                    end
                elseif (length(store_attribute{attri}.Value)<=length(Valu(1,:)))
                    Valu(attri,:) = [store_attribute{attri}.Value zeros((length(Valu(1,:)))-(length(store_attribute{attri}.Value)),1)']; % Added zeros with respect to first element 
                end
            end
        else
            Valu(attri,1) = string('Null');
        end
%         if nnz(double(ismember(fields,'CoderInfo'))')
%             inp_CoderInfo(attri,1)=string(store_attribute{attri}.CoderInfo);end
        if nnz(double(ismember(fields,'Description'))')
            Description(attri,1)=string(store_attribute{attri}.Description);end
        if nnz(double(ismember(fields,'DataType'))')
            DataType(attri,1)=string(store_attribute{attri}.DataType);end
        if nnz(double(ismember(fields,'Min'))')
            Min(attri,1)=string(store_attribute{attri}.Min);end
        if nnz(double(ismember(fields,'Max'))')
            Max(attri,1)=string(store_attribute{attri}.Max);end
        if nnz(double(ismember(fields,'Unit'))')
            Unit(attri,1)=string(store_attribute{attri}.Unit);end
        if nnz(double(ismember(fields,'Complexity'))')
            Complexity(attri,1)=string(store_attribute{attri}.Complexity);end
        if nnz(double(ismember(fields,'Dimensions'))')
            Dimensions(attri,:)=string(store_attribute{attri}.Dimensions);end
        if nnz(double(ismember(fields,'DimensionsMode'))')
            DimensionsMode(attri,1)=string(store_attribute{attri}.DimensionsMode);
        else
            DimensionsMode(attri,1) = string('Null');
        end
        if nnz(double(ismember(fields,'SampleTime'))')
            SampleTime(attri,1)=string(store_attribute{attri}.SampleTime);
        else
            SampleTime(attri,1)= string('Null');
        end
        if nnz(double(ismember(fields,'SamplingMode'))')
            SamplingMode(attri,1)=string(store_attribute{attri}.SamplingMode);
        else
            SamplingMode(attri,1)= string('Null');
        end
        if nnz(double(ismember(fields,'InitialValue'))')
            InitialValue(attri,1)=string(store_attribute{attri}.InitialValue);
        else
            InitialValue(attri,1)= string('Null');    
        end
%         if nnz(double(ismember(fields,'LoggingInfo'))')
%             inp_LoggingInfo(attri,1)=string(store_attribute{attri}.LoggingInfo);
%         end
%         category(attri,1) = repelem(categories{i},length(store_categories),1);
        category{attri,1} = categories{i};
   end
   
  
%    if strmatch(categories{i},'Axis','exact')
        data1{i,1}=jsonencode(table(category,Name,Valu,Description,DataType,Min,Max,Unit,Complexity,Dimensions,DimensionsMode,SampleTime,SamplingMode,InitialValue))
% data1{i,1}=(table(category,Name,Description,DataType,Min,Max,Unit,Complexity,Dimensions,DimensionsMode,SampleTime,SamplingMode,InitialValue))
        data1{i,1} = string(data1{i,1});
    i=i+1;
    inc = 1;
    lcl_cntr=1;
    clear b;
    b={};
    clear dataObject_Name1;
    dataObject_Name1 = {};
    clearvars category Valu inc_v store_categories name_categories inp_Value DimensionsMode Name Description DataType Min Max SampleTime Unit Complexity Dimensions SamplingMode InitialValue;

end
tp=1;
end
% input_data1=jsonencode(table(inp_dataOb_Name,inp_Descrptn,inp_DataTyp,inp_Min,inp_Max,inp_Unit,inp_InitVal));
% input_data1=jsonencode(table(inp_dataOb_Name,inp_Descrptn,inp_DataTyp,inp_Min,inp_Max,inp_Unit));
