package com.navistar.datadictionary.handler;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.handlers.HandlerUtil;

import com.navistar.datadictionary.categories.editor.InputEditor;
import com.navistar.datadictionary.categories.editorinput.CategoryEditorInput;
import com.navistar.datadictionary.model.Category;

public class CategoryHandler extends AbstractHandler{
	
	 public static final String ID = "com.navistar.datadictionary.handler.CategoryHandler";

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		
		 // get the page
	       IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindow(event);
	       IWorkbenchPage page = window.getActivePage();
	       // get the selection
	       ISelection selection = HandlerUtil.getCurrentSelection(event);
	 
	       Object selectObj = null;  
	 
	 
	       // Having selected on WelcomeNoteView
	       if (selection != null && !selection.isEmpty() && selection instanceof IStructuredSelection ) {
	           selectObj = ((IStructuredSelection) selection).getFirstElement();
	       }
	       
	    // No Selection on WelcomeNoteView
	       else {
	    	   selectObj = new Category();	           
	       }
	 
	       
	       Category category = (Category) selectObj;
	       CategoryEditorInput categoryEditorInput = new CategoryEditorInput(category);
	 
	       boolean found = false;
	       
	       if (!found) {
	           try {	              
	        	   page.openEditor(categoryEditorInput, InputEditor.ID);
	               
	           } catch (PartInitException e) {
	               throw new RuntimeException(e);
	           }
	       }
	 
	 
		
		
		return null;
	}

}
