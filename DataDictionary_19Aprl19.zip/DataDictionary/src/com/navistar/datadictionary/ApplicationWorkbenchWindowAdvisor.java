package com.navistar.datadictionary;

import org.eclipse.swt.graphics.Point;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;
import org.eclipse.ui.application.IWorkbenchWindowConfigurer;
import org.eclipse.ui.application.WorkbenchWindowAdvisor;

public class ApplicationWorkbenchWindowAdvisor extends WorkbenchWindowAdvisor {
	 
	   public ApplicationWorkbenchWindowAdvisor(
	           IWorkbenchWindowConfigurer configurer) {
	       super(configurer);
	   }
	 
	   public ActionBarAdvisor createActionBarAdvisor(
	           IActionBarConfigurer configurer) {
	       return new ApplicationActionBarAdvisor(configurer);
	   }
	 
	   public void preWindowOpen() {
	       IWorkbenchWindowConfigurer configurer = getWindowConfigurer();
	       configurer.setInitialSize(new Point(400, 300));
	       configurer.setShowCoolBar(true);
	       configurer.setShowStatusLine(true);
	       configurer.setShowPerspectiveBar(true);
	       configurer.setTitle("Data Dictionary");
	   }
	   
	   @Override
		public void postWindowOpen() {
			getWindowConfigurer().getWindow().getShell().setMaximized( true );
	   }
	 
	/*   
	   @Override
	   public void postWindowOpen() {
//	       Shell shell = getWindowConfigurer().getWindow().getShell();
//	       shell.setMaximized(true);
	       
	    // Register at events related to the components of the page (View, Editor,..)
	       PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage()
	               .addPartListener(new IPartListener2() {          
	          
	                   // When a View or Editor opened.
	                   @Override
	                   public void partOpened(IWorkbenchPartReference partRef) {
	                       System.out.println("Part OPENED: "
	                               + partRef.getPartName());
	                       IWorkbenchPart part = partRef.getPart(false);
	                       
	                       if (part instanceof WelcomeNoteView) {
	                           WelcomeNoteView deptListView = (WelcomeNoteView) part;
	        
	                           DeptEditor deptEditor = (DeptEditor) partRef
	                                   .getPage().findView(DeptEditor.ID);
	                            
	              
	                           // WelcomeNoteView listen to Property Change of DeptEditor.
	                           if (deptEditor != null) {
	                               deptEditor.addPropertyListener(deptListView);
	                           }
	                       } else if (part instanceof ActivityLogView) {
	                           ActivityLogView deptView = (ActivityLogView) part;
	        
	                           DeptEditor deptEditor = (DeptEditor) partRef
	                                   .getPage().findView(DeptEditor.ID);
	                 
	                           // ActivityLogView listen to Property Change of DeptEditor.
	                           if (deptEditor != null) {
	                               deptEditor.addPropertyListener(deptView);
	                           }
	                       } else if (part instanceof DeptEditor) {
	                           DeptEditor deptEditor = (DeptEditor) part;
	                           ActivityLogView deptView = (ActivityLogView) partRef.getPage()
	                                   .findView(ActivityLogView.ID);
	        
	                  
	                           // ActivityLogView listen to Property Change of DeptEditor.
	                           if (deptView != null) {
	                               deptEditor.addPropertyListener(deptView);
	                           }
	        
	                           WelcomeNoteView deptListView = (WelcomeNoteView) partRef
	                                   .getPage().findView(WelcomeNoteView.ID);
	        
	                 
	                           // WelcomeNoteView listen to Property Change of DeptEditor.
	                           if (deptListView != null) {
	                               deptEditor.addPropertyListener(deptListView);
	                           }
	                       }
	                   }

					@Override
					public void partActivated(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partBroughtToTop(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partClosed(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partDeactivated(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partHidden(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partVisible(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void partInputChanged(IWorkbenchPartReference partRef) {
						// TODO Auto-generated method stub
						
					}
	               });
	   }
	   */
	}