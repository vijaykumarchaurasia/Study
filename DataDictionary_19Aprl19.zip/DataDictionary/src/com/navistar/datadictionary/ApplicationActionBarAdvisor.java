package com.navistar.datadictionary;

import java.util.ArrayList;
import java.util.List;

/**
 * An action bar advisor is responsible for creating, adding, and disposing of
 * the actions added to a workbench window. Each window will be populated with
 * new actions.
 */
import org.eclipse.jface.action.ICoolBarManager;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.swt.SWT;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;
import org.eclipse.ui.actions.ActionFactory.IWorkbenchAction;
import org.eclipse.ui.application.ActionBarAdvisor;
import org.eclipse.ui.application.IActionBarConfigurer;

import com.navistar.datadictionary.action.ActivityLogAction;
import com.navistar.datadictionary.action.ClearListAction;
import com.navistar.datadictionary.action.DataObjectWindowAction;
import com.navistar.datadictionary.action.HelpSearchAction;
import com.navistar.datadictionary.action.IoCompatibilityAction;
import com.navistar.datadictionary.action.ProjectExplorerAction;
import com.navistar.datadictionary.action.RecentLyImportedProjAction;
import com.navistar.datadictionary.action.SearchWindowAction;
import com.navistar.datadictionary.action.TableEditorAction;
import com.navistar.datadictionary.action.WelcomeNoteCustomAction;

 
public class ApplicationActionBarAdvisor extends ActionBarAdvisor {
 
  private IWorkbenchAction saveAction;
  private IWorkbenchAction exitAction;
  private IWorkbenchAction aboutAction;
  
  private IWorkbenchAction importAction;
  private IWorkbenchAction helpSearchAction;
  private IWorkbenchAction saveAllAction;
  private IWorkbenchAction undoAction;
  private IWorkbenchAction redoAction;
  private IWorkbenchAction cutAction;
  private IWorkbenchAction copyAction;
  private IWorkbenchAction pasteAction;
  private IWorkbenchAction deleteAction;
  private IWorkbenchAction searchAction;
  private IWorkbenchAction closeProjAction;
  private IWorkbenchAction resolveincosistencyAction;
  private IWorkbenchAction filterAction;
  private IoCompatibilityAction ioCopatibilityAction;
  private IoCompatibilityAction ioCopatibilityWinAction;
  private WelcomeNoteCustomAction welcomeNoteAction;
  private ProjectExplorerAction projectExplorerAction;
  private DataObjectWindowAction dataObjectWindowAction;
  private ActivityLogAction activityLogAction;
  private TableEditorAction tableEditorAction;
  private SearchWindowAction searchWindowAction;
  private IWorkbenchAction resetPerspectiveAction;
  
  public ApplicationActionBarAdvisor(IActionBarConfigurer configurer) {
      super(configurer);
  }
 
  @Override
  protected void makeActions(IWorkbenchWindow window) {
 
      saveAction = ActionFactory.SAVE.create(window);
      this.register(saveAction);
 
      importAction = ActionFactory.IMPORT.create(window);
      importAction.setAccelerator(SWT.CTRL + 'I');
      this.register(importAction);
      closeProjAction = new RecentLyImportedProjAction();
      closeProjAction.setText("Close Projects");
      closeProjAction.setAccelerator(SWT.CTRL +SWT.SHIFT+ SWT.END);
      closeProjAction.setToolTipText("Close Projects");
      this.register(closeProjAction);
      
      saveAllAction= ActionFactory.SAVE_ALL.create(window);
      this.register(saveAllAction);
      undoAction= ActionFactory.UNDO.create(window);
      this.register(undoAction);
      redoAction= ActionFactory.REDO.create(window);
      this.register(redoAction);
      cutAction= ActionFactory.CUT.create(window);
      this.register(cutAction);
      copyAction= ActionFactory.COPY.create(window);
      this.register(copyAction);
      pasteAction= ActionFactory.PASTE.create(window);
      this.register(pasteAction);
      deleteAction= ActionFactory.DELETE.create(window);
      deleteAction.setAccelerator(SWT.CTRL +'W');
      this.register(deleteAction);
      searchAction= ActionFactory.HELP_SEARCH.create(window);
      ioCopatibilityAction = new IoCompatibilityAction();
      ioCopatibilityAction.setText("Check I/O Compatibility");
      ioCopatibilityAction.setToolTipText("Check I/O Compatibility");
      ioCopatibilityAction.setImageDescriptor(Activator.getImageDescriptor("/icons/consistency.png"));
      this.register(ioCopatibilityAction);
      
      ioCopatibilityWinAction = new IoCompatibilityAction();
      ioCopatibilityWinAction.setText("I/O Compatibility");
      ioCopatibilityWinAction.setToolTipText("I/O Compatibility");
      ioCopatibilityWinAction.setChecked(false);
      this.register(ioCopatibilityWinAction);
     
      welcomeNoteAction = new WelcomeNoteCustomAction();
      welcomeNoteAction.setText("Welcome Note");
      welcomeNoteAction.setToolTipText("Welcome Note");
      welcomeNoteAction.setChecked(false);
      this.register(welcomeNoteAction);
      
      projectExplorerAction = new ProjectExplorerAction();
      projectExplorerAction.setText("Project Explorer");
      projectExplorerAction.setToolTipText("Project Explorer");
      projectExplorerAction.setChecked(false);
      this.register(projectExplorerAction);
      
      dataObjectWindowAction = new DataObjectWindowAction();
      dataObjectWindowAction.setText("Data Object Window");
      dataObjectWindowAction.setToolTipText("Data Object Window");
      dataObjectWindowAction.setChecked(false);
      this.register(dataObjectWindowAction);
      
      activityLogAction = new ActivityLogAction();
      activityLogAction.setText("Activity Log");
      activityLogAction.setToolTipText("Activity Log");
      activityLogAction.setChecked(false);
      this.register(activityLogAction);
      
      tableEditorAction = new TableEditorAction();
      tableEditorAction.setText("Table Editor");
      tableEditorAction.setToolTipText("Table Editor");
      tableEditorAction.setChecked(false);
      this.register(tableEditorAction);
      
      searchWindowAction = new SearchWindowAction();
      searchWindowAction.setText("Search Results");
      searchWindowAction.setToolTipText("Search Results");
      searchWindowAction.setChecked(false);
      this.register(searchWindowAction);
      
      resetPerspectiveAction = ActionFactory.RESET_PERSPECTIVE.create(window);
      this.register(resetPerspectiveAction);
      searchAction.setImageDescriptor(Activator.getImageDescriptor("/icons/search.png"));
      this.register(searchAction);
      
      resolveincosistencyAction= ActionFactory.HELP_SEARCH.create(window);
      resolveincosistencyAction.setImageDescriptor(Activator.getImageDescriptor("/icons/inconsistency.png"));
      this.register(resolveincosistencyAction);
      
      filterAction= ActionFactory.HELP_SEARCH.create(window);
      filterAction.setImageDescriptor(Activator.getImageDescriptor("/icons/filter.png"));
      this.register(filterAction);
      exitAction = ActionFactory.QUIT.create(window);
      this.register(exitAction);
 
      aboutAction = ActionFactory.ABOUT.create(window);
      this.register(aboutAction);
      
      helpSearchAction = new HelpSearchAction();
      helpSearchAction.setText("Help Search");
      helpSearchAction.setToolTipText("Help Search");
      this.register(helpSearchAction);
      
 
      super.makeActions(window);
  }
 
  @Override
  protected void fillMenuBar(IMenuManager menuBar) {
      // File
      MenuManager fileMenu = new MenuManager("&File", "file");
      menuBar.add(fileMenu);
      fileMenu.add(importAction);
      MenuManager recentlyimportedMenu = new MenuManager("&Recently Imported Projects", "Recently Imported Projects");
      recentlyimportedMenu.setImageDescriptor(Activator.getImageDescriptor("/icons/recent.png"));
      List<IWorkbenchAction> projList =new ArrayList<IWorkbenchAction>();
      IWorkbenchAction ProjA = new RecentLyImportedProjAction();
      ProjA.setText("ProjA");
      this.register(ProjA);
      IWorkbenchAction ProjB = new RecentLyImportedProjAction();
      ProjB.setText("ProjB");
      this.register(ProjB);
      IWorkbenchAction ProjC = new RecentLyImportedProjAction();
      ProjC.setText("ProjC");
      this.register(ProjC);
      
      
      projList.add(ProjA);
      projList.add(ProjB);
      projList.add(ProjC);
      for(IWorkbenchAction proj : projList){
  		recentlyimportedMenu.add(proj);
  	}
      IWorkbenchAction clearListAction = new ClearListAction();
      clearListAction.setText("Clear List");
      this.register(clearListAction);
      recentlyimportedMenu.add(new Separator());
      recentlyimportedMenu.add(clearListAction);
      fileMenu.add(recentlyimportedMenu);
      fileMenu.add(new Separator());
      fileMenu.add(saveAction);
      fileMenu.add(saveAllAction);
      fileMenu.add(closeProjAction);
      fileMenu.add(new Separator());
      fileMenu.add(exitAction);
 
      // Edit
      MenuManager editMenu = new MenuManager("&Edit", "edit");
      menuBar.add(editMenu);
      editMenu.add(cutAction);
      editMenu.add(copyAction);
      editMenu.add(pasteAction);
      editMenu.add(deleteAction);
      // Project
      MenuManager projectMenu = new MenuManager("&Project", "edit");
      menuBar.add(projectMenu);
      projectMenu.add(ioCopatibilityAction);
   // Project
      MenuManager windowsMenu = new MenuManager("&Windows", "window");
      menuBar.add(windowsMenu);
      windowsMenu.add(ioCopatibilityWinAction);
      windowsMenu.add(welcomeNoteAction);
      windowsMenu.add(projectExplorerAction);
      windowsMenu.add(dataObjectWindowAction);
      windowsMenu.add(activityLogAction);
      windowsMenu.add(tableEditorAction);
      windowsMenu.add(searchWindowAction);
      windowsMenu.add(new Separator());
      windowsMenu.add(resetPerspectiveAction);
      
      
      // Help
      MenuManager helpMenu = new MenuManager("&Help", "help");
      menuBar.add(helpMenu);
      helpMenu.add(aboutAction);
      helpMenu.add(new Separator());
      helpMenu.add(helpSearchAction);
 
      super.fillMenuBar(menuBar);
  }
 
  @Override
  protected void fillCoolBar(ICoolBarManager coolBar) {
	  
      IToolBarManager saveSaveAllGroup = new ToolBarManager(SWT.FLAT | SWT.RIGHT );
      saveSaveAllGroup.add(importAction);
      saveSaveAllGroup.add(saveAction);
      saveSaveAllGroup.add(saveAllAction);
 
      coolBar.add(saveSaveAllGroup);
      
      
      IToolBarManager undoRedoGroup = new ToolBarManager(SWT.FLAT | SWT.RIGHT );
      undoRedoGroup.add(undoAction);
      undoRedoGroup.add(redoAction);
 
      coolBar.add(undoRedoGroup);
      
      IToolBarManager cutCopyPasteGroup = new ToolBarManager(SWT.FLAT | SWT.RIGHT );
      cutCopyPasteGroup.add(cutAction);
      cutCopyPasteGroup.add(copyAction);
      cutCopyPasteGroup.add(pasteAction);
 
      coolBar.add(cutCopyPasteGroup);
      
 
      IToolBarManager searchToolBar = new ToolBarManager(SWT.FLAT | SWT.RIGHT );
      searchToolBar.add(searchAction);
 
      coolBar.add(searchToolBar);
      IToolBarManager ioFilterGroup = new ToolBarManager(SWT.FLAT | SWT.RIGHT );
     ioFilterGroup.add(ioCopatibilityAction);
     ioFilterGroup.add(resolveincosistencyAction);
     ioFilterGroup.add(filterAction);
 
      coolBar.add(ioFilterGroup);
     /* IToolBarManager toolBar2 = new ToolBarManager(SWT.FLAT | SWT.RIGHT );
 
      toolBar2.add(exitAction);
      coolBar.add(toolBar2);*/
  }
}
