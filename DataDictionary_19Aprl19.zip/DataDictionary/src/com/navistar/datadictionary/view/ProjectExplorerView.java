package com.navistar.datadictionary.view;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

public class ProjectExplorerView extends ViewPart{
	public ProjectExplorerView() {
	}
	
	public static final String ID = "com.navistar.datadictionary.view.ProjectExplorerView";

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		
		 Composite container = new Composite(parent, SWT.NONE);
	    container.setLayout(new GridLayout(3, false));

	    Label lblDeptNo = new Label(container, SWT.NONE);
	    lblDeptNo.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false,
	            false, 1, 1));
	    new Label(container, SWT.NONE);
	    
	    Composite composite = new Composite(container, SWT.NONE);
	    
	    Button btnHideShowView = new Button(composite, SWT.NONE);
	    btnHideShowView.setBounds(0, 10, 93, 29);
	    btnHideShowView.setText("Show View");
	    
	    btnHideShowView.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) 
			{
				try 
				{
					if (btnHideShowView.getText().equals("Show View"))
					{
						PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().showView(ActivityLogView.ID);
						btnHideShowView.setText("Hide View");
					}
					else
					{
						IViewReference[] views = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getViewReferences();
						for (IViewReference iViewReference : views) {
							 if ( iViewReference.getId().equals(ActivityLogView.ID) ) 
							 {
								 	iViewReference.getPage().hideView(iViewReference);
								 	btnHideShowView.setText("Show View");
									break;
							}
						}
						
					}
					
				} catch (PartInitException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
	  // lblDeptNo.setText("Project Explorer View");
		
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}
