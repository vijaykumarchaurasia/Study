package com.navistar.datadictionary.view;

import org.eclipse.swt.widgets.Composite;

public class IOCompatibilityView extends AbstractViewPart{
	public static final String ID = "com.navistar.datadictionary.view.IOCompatibilityView";

	@Override
	public void createPartControl(Composite parent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getAdapter(Class arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
