package com.navistar.datadictionary.other;

public interface DirtyListener {
	public void fireDirty();

}
