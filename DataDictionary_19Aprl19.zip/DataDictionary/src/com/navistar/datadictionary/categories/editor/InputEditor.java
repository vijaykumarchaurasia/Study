package com.navistar.datadictionary.categories.editor;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.DefaultNatTableStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IEditableRule;
import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.data.ListDataProvider;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultColumnHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultCornerDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultRowHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.layer.ColumnHeaderLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.CornerLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.GridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.RowHeaderLayer;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.viewport.ViewportLayer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;

import com.navistar.datadictionary.editor.AbstractBaseEditor;
import com.navistar.datadictionary.model.Department;
import com.navistar.datadictionary.model.DepartmentDAO;
import com.navistar.datadictionary.provider.DepartmentColumnPropertyAccessor;

public class InputEditor extends AbstractBaseEditor {
	public static final String ID = "com.navistar.datadictionary.categories.editor.InputEditor";

	public InputEditor() {
	}

	@Override
	public void showData() {

	}

	@Override
	protected void createPartControl2(Composite parent) {
		
		parent.setLayout(new GridLayout(2,false));
		Button btnAddDataObj = new Button(parent, SWT.PUSH);
		btnAddDataObj.setBounds(10, 20, 75, 25);
		btnAddDataObj.setText("Add data object");
		
		Button btnNewButton = new Button(parent, SWT.PUSH);
		btnNewButton.setBounds(10, 20, 75, 25);
		btnNewButton.setText("Find in model");
		
		// property names of the Department class
		String[] propertyNames = { "deptId", "deptNo", "deptName", "location" };
		   
		// mapping from property to label, needed for column header labels
		Map<String, String> propertyToLabelMap = new HashMap<String, String>();
		propertyToLabelMap.put("deptId", "Department_ID");
		propertyToLabelMap.put("deptNo", "Department_No");
		propertyToLabelMap.put("deptName", "Department_Name");
		propertyToLabelMap.put("location", "Department_Location");
		
		// create the data provider
		//IColumnPropertyAccessor<Department> columnPropertyAccessor = new ReflectiveColumnPropertyAccessor<Department>(propertyNames);
		IColumnPropertyAccessor<Department> columnPropertyAccessor = new DepartmentColumnPropertyAccessor();

		IDataProvider bodyDataProvider =
		           new ListDataProvider<Department>(
		           		DepartmentDAO.listDepartment(), columnPropertyAccessor);
		   
		   final DataLayer bodyDataLayer = new DataLayer(bodyDataProvider);
		   //DepartmentHeaderDataProvider headerDataProvider = new DepartmentHeaderDataProvider();
		   
		   SelectionLayer selectionLayer = new SelectionLayer(bodyDataLayer);
		   ViewportLayer viewportLayer = new ViewportLayer(selectionLayer);
		   
		   // build the column header layer stack
		   IDataProvider columnHeaderDataProvider = new DefaultColumnHeaderDataProvider(propertyNames, propertyToLabelMap);
		   DataLayer columnHeaderDataLayer = new DataLayer(columnHeaderDataProvider);
		   ILayer columnHeaderLayer = new ColumnHeaderLayer(columnHeaderDataLayer,
				    										viewportLayer,
				    										selectionLayer);
				
		   // build the row header layer stack
		   IDataProvider rowHeaderDataProvider = new DefaultRowHeaderDataProvider(bodyDataProvider);
		   DataLayer rowHeaderDataLayer = new DataLayer(rowHeaderDataProvider, 40, 20);
		   ILayer rowHeaderLayer = new RowHeaderLayer(rowHeaderDataLayer,viewportLayer,selectionLayer);
		   
		   // build the corner layer stack
		   IDataProvider cornerDataProvider = new DefaultCornerDataProvider(columnHeaderDataProvider,rowHeaderDataProvider);
		   DataLayer cornerDataLayer = new DataLayer(cornerDataProvider);
		   ILayer cornerLayer = new CornerLayer(cornerDataLayer,rowHeaderLayer,columnHeaderLayer);

		   // create the grid layer composed with
		   // the prior created layer stacks
		   GridLayer gridLayer = new GridLayer(viewportLayer,columnHeaderLayer,rowHeaderLayer,cornerLayer);
		   //DefaultGridLayer gridLayer = new DefaultGridLayer(bodyDataProvider, headerDataProvider);
		   NatTable natTable = new NatTable(parent, gridLayer, false);
		  
		   natTable.addConfiguration(new DefaultNatTableStyleConfiguration());
		   natTable.addConfiguration(new AbstractRegistryConfiguration() {

		       @Override
		       public void configureRegistry(IConfigRegistry configRegistry) {
		           configRegistry.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,
		                   IEditableRule.ALWAYS_EDITABLE);		         
		       }
		   });

		   natTable.configure();
		   GridDataFactory.fillDefaults().grab(true, true).applyTo(natTable);
		   
		   
	}

	@Override
	protected Control[] registryDirtyControls() {
		return null;
	}

	@Override
	public void doSave(IProgressMonitor monitor) {
	}

	@Override
	public Object getAdapter(Class arg0) {
		return null;
	}
}
