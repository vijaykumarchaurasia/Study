package com.navistar.datadictionary;

import org.eclipse.ui.IFolderLayout;
import org.eclipse.ui.IPageLayout;
import org.eclipse.ui.IPerspectiveFactory;

import com.navistar.datadictionary.categories.editor.InputEditor;
import com.navistar.datadictionary.view.ActivityLogView;
import com.navistar.datadictionary.view.DataObjectView;
import com.navistar.datadictionary.view.IOCompatibilityView;
import com.navistar.datadictionary.view.ProjectExplorerView;

public class Perspective implements IPerspectiveFactory {

	@Override	
	public void createInitialLayout(IPageLayout layout) {	
		displayLayout(layout);	
	}
	
	private void displayLayout(IPageLayout layout)
	{
		String editorArea = layout.getEditorArea();

        layout.setEditorAreaVisible(false);       

        layout.addStandaloneView(ProjectExplorerView.ID,  true, IPageLayout.LEFT, 0.20f, editorArea);       

        IFolderLayout topViewFolder = layout.createFolder("messages", IPageLayout.TOP, 0.5f, editorArea);

       // topViewFolder.addView(WelcomeNoteView.ID);  
        topViewFolder.addView(InputEditor.ID);

        IFolderLayout bottomViewFolder = layout.createFolder("messages", IPageLayout.BOTTOM, 0.5f, editorArea);

        bottomViewFolder.addView(ActivityLogView.ID);
        bottomViewFolder.addView(IOCompatibilityView.ID);
        bottomViewFolder.addView(DataObjectView.ID);
		
	}
	
	
	
	
}

