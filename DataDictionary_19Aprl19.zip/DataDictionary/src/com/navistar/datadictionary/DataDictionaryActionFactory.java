package com.navistar.datadictionary;

import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.actions.ActionFactory;

public class DataDictionaryActionFactory extends ActionFactory{

	protected DataDictionaryActionFactory(String actionId, String commandId) {
		super(actionId, commandId);
		// TODO Auto-generated constructor stub
	}

	@Override
	public IWorkbenchAction create(IWorkbenchWindow window) {
		// TODO Auto-generated method stub
		return null;
	}

}
