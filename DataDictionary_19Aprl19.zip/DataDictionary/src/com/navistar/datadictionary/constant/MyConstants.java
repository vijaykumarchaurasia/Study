package com.navistar.datadictionary.constant;

public class MyConstants {
	public static final int EDITOR_DATA_CHANGED = 999999; 
	public static final String CATEGORY_INPUT = "Input";

}
